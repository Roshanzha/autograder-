"""Generate genuine sample reports after Ubuntu/Docker/Ollama setup."""
import json
from app import ROOT, grade


def main():
    summary = []
    for source in sorted((ROOT / "examples").glob("*.c")):
        report, paths = grade(source, ROOT / "rules/add.json")
        summary.append({"sample": source.name, "grade": report["grade"],
                        "status": report["status"], "reports": paths})
        print(source.name, report["status"], report["grade"])
    (ROOT / "data/sample-index.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return 2 if any(item["grade"] is None for item in summary) else 0


if __name__ == "__main__":
    raise SystemExit(main())
