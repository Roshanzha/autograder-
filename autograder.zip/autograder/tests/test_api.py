"""API contracts use real HTTP routing with fake grading, not fake grading claims."""
import json
import threading
import time
import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from api import create_app, JobStore
from grader.coordinator import evaluate
from grader.files import load_rules
from test_unit import ROOT, FakeSandbox, FakeLLM


def fake_evaluator(source, rules_path, corpus):
    rules = load_rules(rules_path)
    report = evaluate(source.read_text(), rules, FakeSandbox(), FakeLLM(), "test")
    report["submission"] = source.name
    return report, ()


class APITests(unittest.TestCase):
    def setUp(self):
        self.store = JobStore(fake_evaluator)
        self.client = TestClient(create_app(self.store))
        self.payload = {"filename": "add.c", "source": (ROOT / "examples/add_original.c").read_text(),
                        "rules": load_rules(ROOT / "rules/add.json").model_dump()}

    def tearDown(self):
        self.client.close()
        self.store.close()

    def test_rules_endpoint(self):
        result = self.client.get("/api/rules")
        self.assertEqual(result.status_code, 200)
        self.assertEqual(len(result.json()["metrics"]), 9)

    def test_job_round_trip(self):
        with patch("api.platform.system", return_value="Linux"):
            response = self.client.post("/api/evaluations", json=self.payload)
        self.assertEqual(response.status_code, 202)
        key = response.json()["id"]
        for _ in range(100):
            job = self.client.get(f"/api/evaluations/{key}").json()
            if job["status"] in {"complete", "error"}:
                break
            time.sleep(.01)
        self.assertEqual(job["status"], "complete")
        self.assertEqual(job["report"]["submission"], "add.c")
        self.assertIn("Grade:", job["text"])

    def test_rejects_invalid_weights(self):
        self.payload["rules"]["metrics"][0]["weight"] = .9
        self.assertEqual(self.client.post("/api/evaluations", json=self.payload).status_code, 422)

    def test_rejects_filename_traversal(self):
        self.payload["filename"] = "../add.c"
        self.assertEqual(self.client.post("/api/evaluations", json=self.payload).status_code, 422)

    def test_request_body_cap(self):
        response = self.client.post("/api/evaluations", content=b"x" * 200001,
                                    headers={"Content-Type": "application/json"})
        self.assertEqual(response.status_code, 413)

    def test_external_origin_rejected(self):
        response = self.client.post("/api/evaluations", json=self.payload,
                                    headers={"Origin": "https://untrusted.example"})
        self.assertEqual(response.status_code, 403)

    def test_windows_grading_explained(self):
        with patch("api.platform.system", return_value="Windows"):
            response = self.client.post("/api/evaluations", json=self.payload)
        self.assertEqual(response.status_code, 503)
        self.assertIn("Ubuntu", response.json()["detail"])

    def test_report_traversal_and_missing_job(self):
        self.assertEqual(self.client.get("/api/reports/not-a-hash/secret.json").status_code, 404)
        self.assertEqual(self.client.get("/api/evaluations/missing").status_code, 404)

    def test_background_failure_is_visible(self):
        def fail(*args):
            raise RuntimeError("Ollama not connected")
        self.store.evaluator = fail
        with patch("api.platform.system", return_value="Linux"):
            key = self.client.post("/api/evaluations", json=self.payload).json()["id"]
        for _ in range(100):
            job = self.client.get(f"/api/evaluations/{key}").json()
            if job["status"] == "error":
                break
            time.sleep(.01)
        self.assertEqual(job["error"], "Ollama not connected")
