"""FastAPI boundary for the React application.

Requests contain source + instructor rules as JSON. Long-running evaluations use
a bounded background queue so the browser can poll real job state without timing
out. Student code is still executed exclusively by the existing Docker worker.
"""
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import tempfile
import threading
import uuid

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import Field
import requests

from backend import grade, ROOT
from grader.files import load_rules
from grader.models import StrictModel, Rules
from grader.reporting import as_text


class EvaluationRequest(StrictModel):
    filename: str = Field(min_length=3, max_length=100, pattern=r"^[A-Za-z0-9_.-]+\.c$")
    source: str = Field(min_length=1, max_length=12000)
    rules: Rules


class JobStore:
    """One active evaluation and one waiting request; retained results stay bounded."""
    def __init__(self, evaluator=grade):
        self.evaluator = evaluator
        self.pool = ThreadPoolExecutor(max_workers=1, thread_name_prefix="grader")
        self.slots = threading.BoundedSemaphore(2)
        self.lock = threading.Lock()
        self.jobs = {}

    def submit(self, payload):
        if not self.slots.acquire(blocking=False):
            raise HTTPException(429, "Evaluator busy. Wait for a current evaluation to finish.")
        key = uuid.uuid4().hex
        with self.lock:
            # Reports remain on disk; only the latest 50 job states remain in RAM.
            for old in list(self.jobs):
                if len(self.jobs) < 50:
                    break
                if self.jobs[old]["status"] in {"complete", "error"}:
                    del self.jobs[old]
            self.jobs[key] = {"id": key, "status": "queued", "filename": payload.filename}
        self.pool.submit(self._run, key, payload)
        return self.get(key)

    def _run(self, key, payload):
        with self.lock:
            self.jobs[key]["status"] = "running"
        try:
            with tempfile.TemporaryDirectory(prefix="autograder-api-") as directory:
                folder = Path(directory)
                source = folder / payload.filename
                source.write_text(payload.source, encoding="utf-8")
                rules_path = folder / "rules.json"
                rules_path.write_text(payload.rules.model_dump_json(indent=2), encoding="utf-8")
                report, _ = self.evaluator(source, rules_path, os.getenv("AUTOGRADER_CORPUS") or None)
            result = {"status": "complete", "report": report, "text": as_text(report)}
        except Exception as exc:
            result = {"status": "error", "error": str(exc)}
        finally:
            self.slots.release()
        with self.lock:
            self.jobs[key].update(result)

    def get(self, key):
        with self.lock:
            if key not in self.jobs:
                raise HTTPException(404, "Evaluation not found (the server may have restarted).")
            return dict(self.jobs[key])

    def close(self):
        self.pool.shutdown(wait=True)


def runtime_health():
    """Fast, honest readiness probes; never report a model as connected speculatively."""
    rules = load_rules(Path(os.getenv("AUTOGRADER_RULES", str(ROOT / "rules/add.json"))))
    checks = {"platform": {"ready": platform.system() == "Linux", "detail": platform.system()},
              "docker": {"ready": False, "detail": "Docker unavailable"},
              "ollama": {"ready": False, "detail": "Ollama unavailable"}}
    image = os.getenv("AUTOGRADER_IMAGE", "autograder-sandbox:1")
    if shutil.which("docker"):
        try:
            check = subprocess.run(["docker", "image", "inspect", image], capture_output=True, timeout=3)
            checks["docker"] = {"ready": check.returncode == 0,
                                "detail": image if check.returncode == 0 else "Build the sandbox image"}
        except (OSError, subprocess.TimeoutExpired):
            checks["docker"]["detail"] = "Docker is not responding"
    try:
        # Reuse the endpoint validation from the actual evaluator client.
        from grader.ollama_client import OllamaClient
        client = OllamaClient(rules.llm, os.getenv("OLLAMA_URL", "http://127.0.0.1:11434"))
        response = client.session.get(client.base_url + "/api/tags", timeout=2, allow_redirects=False)
        response.raise_for_status()
        models = [m["name"] for m in response.json()["models"]]
        ready = any(name in {rules.llm.model, rules.llm.model + ":latest"} for name in models)
        checks["ollama"] = {"ready": ready, "detail": rules.llm.model if ready else "Configured model is not installed"}
    except (requests.RequestException, ValueError, KeyError):
        pass
    return {"ready": all(c["ready"] for c in checks.values()), "checks": checks,
            "model": rules.llm.model, "mode": "local"}


def create_app(store=None):
    jobs = store or JobStore()

    @asynccontextmanager
    async def lifespan(app):
        yield
        jobs.close()

    app = FastAPI(title="AutoGrader API", version="2.0.0", lifespan=lifespan)

    @app.middleware("http")
    async def local_request_boundary(request: Request, call_next):
        # The server is a local instructor tool. Reject cross-origin browser writes.
        allowed = {f"http://{host}:{port}" for host in ("localhost", "127.0.0.1")
                   for port in (5173, 7860, 7861, 8000)}
        origin = request.headers.get("origin")
        if request.method not in {"GET", "HEAD", "OPTIONS"} and origin and origin not in allowed:
            return JSONResponse({"detail": "Cross-origin writes are not allowed"}, status_code=403)
        if request.url.path.startswith("/api/") and request.method == "POST":
            # Bound the actual body even when Content-Length is missing or misleading.
            body = bytearray()
            async for chunk in request.stream():
                body.extend(chunk)
                if len(body) > 200_000:
                    return JSONResponse({"detail": "Request exceeds 200 KB"}, status_code=413)
            request._body = bytes(body)
        return await call_next(request)

    @app.get("/api/health")
    def health():
        return runtime_health()

    @app.get("/api/rules")
    def default_rules():
        rules = load_rules(Path(os.getenv("AUTOGRADER_RULES", str(ROOT / "rules/add.json"))))
        # The expanded test set is self-contained for the browser JSON editor.
        rules.testset_dir = None
        return rules.model_dump()

    @app.post("/api/evaluations", status_code=202)
    def submit(payload: EvaluationRequest):
        if payload.rules.testset_dir:
            raise HTTPException(422, "Web rules must use inline tests; testset_dir is CLI-only.")
        if len(payload.source.encode("utf-8")) > 12000:
            raise HTTPException(422, "C source exceeds 12 KB.")
        if platform.system() != "Linux":
            raise HTTPException(503, "Real grading requires Ubuntu/Linux with Docker and Ollama. The interface can be previewed here.")
        return jobs.submit(payload)

    @app.get("/api/evaluations/{job_id}")
    def status(job_id: str):
        return jobs.get(job_id)

    @app.get("/api/reports")
    def history():
        folder = ROOT / "data/reports"
        paths = sorted(folder.glob("*/*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:50]
        items = []
        for path in paths:
            try:
                report = json.loads(path.read_text(encoding="utf-8"))
                items.append({"id": path.parent.name, "file": path.name,
                              "submission": report.get("submission", path.stem),
                              "grade": report["grade"], "status": report["status"]})
            except (OSError, ValueError, KeyError):
                continue
        return items

    @app.get("/api/reports/{evaluation_id}/{filename}")
    def get_report(evaluation_id: str, filename: str):
        if not re.fullmatch(r"[a-f0-9]{64}", evaluation_id) or not re.fullmatch(r"[A-Za-z0-9_-]+\.(json|txt)", filename):
            raise HTTPException(404, "Report not found")
        folder = (ROOT / "data/reports").resolve()
        path = (folder / evaluation_id / filename).resolve()
        if not path.is_relative_to(folder) or not path.is_file():
            raise HTTPException(404, "Report not found")
        return FileResponse(path, media_type="application/json" if path.suffix == ".json" else "text/plain")

    # In production FastAPI serves the built React app and the API on one origin.
    dist = ROOT / "web/dist"
    if dist.exists():
        app.mount("/", StaticFiles(directory=dist, html=True), name="react")
    return app


app = create_app()
