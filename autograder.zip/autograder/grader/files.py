"""Bounded file loading and atomic JSON persistence. No vector store is needed."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
from .models import Rules, TestCase


def read_text(path: Path, limit: int = 100_000) -> str:
    if path.stat().st_size > limit:
        raise ValueError(f"File exceeds {limit} bytes: {path.name}")
    return path.read_text(encoding="utf-8")


def digest(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True,
                                    separators=(",", ":")).encode()).hexdigest()


def under(root: Path, relative: str) -> Path:
    """Reject absolute paths, traversal and symlinks escaping a trusted directory."""
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Resource path must stay inside its configured directory")
    return path


def load_rules(path: Path) -> Rules:
    rules = Rules.model_validate_json(read_text(path))
    if rules.testset_dir:
        folder = under(path.parent, rules.testset_dir)
        inputs = sorted(folder.glob("*.in"))
        if not inputs or len(inputs) + len(rules.tests) > 100:
            raise ValueError("External test set must contain pairs and total at most 100 cases")
        for item in inputs:
            # Resolve both members so a symlink cannot escape the rules folder.
            inp = under(path.parent, str(item.relative_to(path.parent)))
            out = under(path.parent, str(item.with_suffix(".out").relative_to(path.parent)))
            rules.tests.append(TestCase(name=item.stem, input=read_text(inp, 8192),
                                        expected=read_text(out, 8192)))
    return rules


def atomic_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(data, stream, indent=2, ensure_ascii=True, allow_nan=False)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)

