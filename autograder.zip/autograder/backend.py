"""Backend service: loads rules, calls evaluator agents and saves JSON/text reports.

The FastAPI service, optional Gradio frontend and CLI call grade(); no UI code lives here.
"""
import os
from pathlib import Path
import sys
from grader.coordinator import evaluate
from grader.files import load_rules, read_text
from grader.ollama_client import OllamaClient
from grader.reporting import as_text, save_report
from grader.sandbox import DockerSandbox
from grader.locking import grading_lock

ROOT = Path(__file__).resolve().parent


def load_corpus(folder, submission):
    if not folder:
        return {}
    folder = Path(folder).resolve()
    files = sorted(folder.glob("*.c"))
    if len(files) > 20:
        raise ValueError("This prototype supports at most 20 reference files per corpus")
    return {p.name: read_text(p, 12000) for p in files
            if p.resolve() != submission.resolve() and p.resolve().is_relative_to(folder)}


def grade(submission, rules_path, corpus=None):
    source_path = Path(submission)
    if source_path.suffix.lower() != ".c":
        raise ValueError("Upload a single UTF-8 .c source file")
    source = read_text(source_path, 12000)
    rules = load_rules(Path(rules_path))
    with grading_lock(ROOT / "data/grade.lock"):
        report = evaluate(source, rules,
                          DockerSandbox(os.getenv("AUTOGRADER_IMAGE", "autograder-sandbox:1")),
                          OllamaClient(rules.llm, os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")),
                          read_text(ROOT / "prompts/evaluator.txt"),
                          load_corpus(corpus, source_path), ROOT / "data/cache")
        # Filename is presentation metadata, so attach it after verdict-cache lookup.
        report["submission"] = source_path.name
        paths = save_report(report, ROOT / "data/reports")
    return report, paths


