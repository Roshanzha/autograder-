# AutoGrader implementation report

## Scope and architecture

The supplied assignment requires rule-driven C evaluation, specialist analyzers,
bounded execution, counterexamples, reproducible grading and explanatory reports.
The implementation uses ordinary file handling because the submission, rules and
small comparison corpus fit directly in memory. Retrieval would add indexing and
embedding dependencies without improving the evaluation contract.

The coordinator validates a rules file, resolves the local model and compiler
image identities, checks the verdict cache, compiles the submission and performs
a smoke run. It then dispatches each metric to its specialist and aggregates
normalized scores. The React frontend in `web/src/main.jsx` calls the JSON API in `api.py`, which
uses the Python service in `backend.py`; `app.py` is the main entry point. The frontend has no grading logic. All components include
docstrings and comments describing responsibilities and non-obvious decisions.

Ollama is the primary semantic evaluator: four independent specialist
conversations analyze structure, modularity, complexity and readability. Each
uses a separate role and rubric. These are bounded agents, not unrestricted
tool-using chat loops: the coordinator owns tool execution and evidence flow.
Compiler, test and sanitizer facts cannot be overridden by an LLM response.
Sequential dispatch avoids competition for local model RAM and student runtime
CPU; adding parallelism should preserve these isolation and reproducibility goals.

## Requirement mapping

| Requirement | Implementation |
|---|---|
| Safe bounded C execution | Docker sandbox + process-group termination + cgroup and rlimit budgets |
| External editable instructions | `rules/add.json`, `prompts/evaluator.txt` |
| Independent analyzers | Nine analyzer modules and explicit registry |
| Single overall weighted grade | Coordinator aggregation, weight/score validation |
| Specific failure examples | I/O mismatch records with input, expected, observed, status and diagnostics |
| Generated corner cases | Seeded int32 arithmetic generator and trusted Python oracle |
| Memory errors / undefined behavior | ASan, LeakSanitizer behavior from ASan, and UBSan test runs |
| Complexity | Source-based Ollama estimate with explicit uncertainty; no timing proof claim |
| Copying flags | Local corpus token comparison; saved web/LLM exemplars can be included |
| Reproducible result | Input/environment fingerprint + persistent verdict cache + serialized writes |
| Unattended workflow | CLI and sample batch driver |
| Reports | JSON/text outputs plus usefulness and limitations in every report |

## Deliberate corrections to the assignment illustration

The example weights are valid: 20% plus eight 10% weights is 100%. However, its
listed contributions add to 79, not 89, and 8/10 passing tests imply 0.8, not 0.9.
The example program has no unused parameter, so this implementation does not
manufacture the shown warning. Real diagnostics come from the installed GCC.

Signed integer overflow in C is undefined; `INT_MAX + 1` has no guaranteed wrapped
output. The included rules explicitly require a mathematical sum for int32 inputs
and therefore expect `2147483648` for `2147483647 1`. The corrected sample uses
`long long`. The original sample should fail those boundary cases and UBSan.
No exact overall grade is asserted before the real local model evaluates it.

The example provider/model name is replaced by an actual local Ollama model tag.
No API key or Groq/cloud integration is used. The server command is `ollama serve`.

## Security and operational boundaries

Neither student source nor compiled executables run on the host. Source/binary
data enter fresh containers through stdin; the host filesystem and Docker socket
are not mounted. Containers have no network, a read-only root, a bounded temporary
filesystem, no-new-privileges,
pid/CPU/memory limits and bounded output. The worker additionally enforces wall
timeouts and kills process groups. Containers are force-removed after each job.

The supervisor has only SETUID/SETGID/KILL capabilities and starts compiler/student
children as UID/GID 65534 with no effective capabilities. This separates protocol
ownership from submitted code and prevents student access to supervisor protocol
descriptors through `/proc`. The host also bounds Docker output. A container-wide
OOM can still disrupt the supervisor and force an incomplete report.
Docker shares the host kernel and is not a complete isolation guarantee against
kernel exploits. Public adversarial grading needs a dedicated VM/microVM boundary,
authentication, quotas, queue isolation and host hardening. This implementation is
a local instructor prototype, not a public multi-tenant judge.

Rules, prompts and corpus files are instructor-controlled. No student-selected
shell command, dynamic Python import, compiler plugin or arbitrary Docker option
is accepted. Student comments can still influence a language model despite prompt
boundaries; consequential subjective deductions require calibration/review.

## Reproducibility contract

The same persisted evaluation key replays the same grade. The key includes
submission, rules with test contents, corpus contents, prompt, Python grader
implementation and model/container identities. Changes invalidate the cache.
This is a practical audit/replay contract, not a proof of deterministic fresh
inference. Keep the runtime and cache fixed for an evaluation cohort. Failed
services are not cached; an incomplete report has no official grade.

## Usefulness: four concrete applications

1. **University labs:** 300 addition submissions are checked against the same
   boundary cases. Students receive an exact failing input instead of a generic
   'wrong answer', reducing repetitive instructor feedback.
2. **Self-directed practice:** a learner uploads a hanging solution, sees the
   timeout, fixes termination and receives the remaining metric evaluations on
   the next run.
3. **Interview assistance:** reviewers inspect per-metric evidence across 50 C
   exercises and reserve human time for design reasoning and borderline results.
4. **Reference-copying triage:** a high-similarity match to a locally saved tutorial
   or peer solution identifies a specific pair for manual inspection.

## Limitations: four concrete unreliable-verdict cases

1. **Finite coverage:** a student hard-codes the known/generated test inputs and
   passes all tests but fails an unseen valid pair. More randomized/hidden tests
   reduce exposure but cannot establish general correctness.
2. **Semantic-model error:** a macro hides an input-dependent loop and the
   complexity specialist incorrectly awards O(1), or it penalizes conventional
   mathematical variable names. Calibrate against instructor-scored examples and
   audit line-level feedback; model output is not a proof.
3. **Authorship uncertainty:** independently written five-line addition solutions
   may be very similar; renamed copied code may evade comparison. Online copying
   outside the local corpus and LLM authorship remain unknown. Flags are advisory
   by default, never automatic misconduct conclusions.
4. **Execution/inference variability:** a near-timeout program may pass on an idle
   host and fail under load, or ASan overhead may exceed the instrumented budget.
   Fresh local model inference can vary across hardware/runtime versions even at
   temperature zero. Cache replay preserves a verdict but cannot make an erroneous
   verdict correct or ensure identical independent recomputation.

## Sample outputs and validation

`examples/add_original.c` reproduces the PDF source; additional examples cover a
corrected solution, wrong arithmetic, nontermination, compilation failure, crash
and output flooding. `python run_samples.py` creates genuine JSON/text reports
and `data/sample-index.json` on the Ubuntu target. No fabricated Ollama scores or
container execution reports are distributed. See `VALIDATION.md` for actual tests.

## Suggested team ownership and four-week schedule

These are suggested roles, not claims about actual team membership or work done.

| Role | Ownership | Review partner |
|---|---|---|
| Member A | Rules, file operations, coordinator, cache | Member B |
| Member B | Docker worker, correctness, compiler, sanitizer checks | Member A |
| Member C | Ollama client, prompts, structure/modularity/complexity/readability | Member D |
| Member D | React, FastAPI integration, reporting, tests and documentation | Member C |

Week 1: agree on input/output/overflow semantics; run the skeleton and validate
rules. Week 2: verify sandbox limits and deterministic tool evidence on all
failure fixtures. Week 3: calibrate Ollama specialists against hand-graded samples
and review originality false positives. Week 4: run full Ubuntu acceptance tests,
archive runtime versions and sample reports, review code as a team and record a
15–20 minute demonstration explaining design tradeoffs and known failures.

Video outline: problem/rules (2 min), architecture (3 min), correct and incorrect
examples (4 min), timeout/sanitizer/originality demos (4 min), reproducibility and
limits (3 min), team ownership and conclusions (2 min). Repository publication,
video recording/uploading and institutional submission remain team activities.
