"""Explicit registry: rules select capabilities, never arbitrary imports or commands."""
from .correctness import CorrectnessAgent
from .syntax import SyntaxAgent
from .structure import StructureAgent
from .modularity import ModularityAgent
from .edges import EdgeCaseAgent
from .complexity import ComplexityAgent
from .memory import MemorySafetyAgent
from .readability import ReadabilityAgent
from .originality import OriginalityAgent
from .rubric import RubricAgent

REGISTRY = {
    "io_tests": CorrectnessAgent, "compiler_warnings": SyntaxAgent,
    "static_analysis": StructureAgent, "function_split": ModularityAgent,
    "edge_case_runner": EdgeCaseAgent, "complexity_estimator": ComplexityAgent,
    "sanitizer_run": MemorySafetyAgent, "llm_review": ReadabilityAgent,
    "similarity_flag": OriginalityAgent, "llm_rubric": RubricAgent,
}
