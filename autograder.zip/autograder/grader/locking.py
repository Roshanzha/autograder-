"""Serialize grading on Ubuntu so concurrent requests cannot race the verdict cache."""
from contextlib import contextmanager


@contextmanager
def grading_lock(path):
    import fcntl  # Linux-only by design; Docker execution target is Ubuntu.
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)
