"""Modularity specialist, separate from formatting/readability evaluation."""
from .rubric import RubricAgent


class ModularityAgent(RubricAgent):
    role = "modularity: function boundaries, helper functions and responsibility separation"
