# AutoGrader — React + Python + local Ollama

A runnable local application for grading C programs. The **React interface** talks
to a **FastAPI Python backend** using JSON. The backend coordinates nine specialist
analyzers, compiles/runs student code in Docker, and uses local Ollama for semantic
reviews. No RAG, cloud model API, LangChain or ChromaDB is needed.

## Start here: Ubuntu

### 1. System prerequisites (one time)

Use Ubuntu 24.04, Python 3.10+, **Node.js 22.12 or newer**, Docker Engine and Ollama.
Node is needed to build the frontend; the finished app runs with Python alone.

```bash
sudo apt update
sudo apt install -y python3-venv python3-pip docker.io curl
sudo systemctl enable --now docker
sudo usermod -aG docker "$USER"
```

Log out and back in for Docker permissions. Check `docker info`.
Install Node.js from https://nodejs.org/en/download and verify `node --version`.
Use Node 22.12+; Ubuntu's default `nodejs` package may be older.

Install Ollama using https://docs.ollama.com/linux, then:

```bash
ollama pull qwen2.5-coder:7b
```

If its service is not running, start `ollama serve` in another terminal. The model
needs its own RAM/VRAM, separate from the student program memory limit.

### 2. Prepare the project (one time)

Extract the ZIP and open a terminal in the `autograder` folder:

```bash
bash scripts/setup.sh
docker build -t autograder-sandbox:1 sandbox/
.venv/bin/python app.py doctor
```

The setup script creates `.venv`, installs the commented Python requirements,
installs the locked React dependencies, and builds `web/dist`.
Package/model/image downloads need internet once. Grading is local afterward.

### 3. Run frontend and backend together

```bash
bash scripts/start.sh
```

Open **http://127.0.0.1:7860**. One Python process serves both the built React
frontend and the API. Ctrl+C stops it. To use another port:

```bash
bash scripts/start.sh --port 7861
```

The equivalent command is `source .venv/bin/activate` then `python app.py web`.
`python app.py ui` also starts the new React interface. The old Gradio interface is
optional: `pip install -r requirements-gradio.txt` then `python app.py gradio`.

## Use the interface

1. Start from the clearly labeled `add.c` sample, upload a `.c` file, or edit the code.
2. Open **Grading rules** to inspect/edit the JSON, import a rules file, or export it.
3. Click **Evaluate submission**. The browser shows actual queued/running status.
4. Read the metric breakdown, expand feedback, and inspect counterexample inputs.
5. Switch to **Backend JSON** or download JSON/TXT.
6. Open **Past evaluations** to revisit reports saved on this machine.

The readiness indicator checks Ubuntu/Linux, the Docker image and the configured
Ollama model. A missing dependency produces an actionable error, never a fake
successful grade. On Windows the React interface and API can be previewed, but
real grading must run in Ubuntu (including an appropriate Ubuntu VM/WSL setup).

This is a local **instructor** interface. It permits rule editing and reveals test
inputs. It is not an authenticated public student examination portal.

## Separate frontend/backend development

Terminal 1, from the project root:

```bash
source .venv/bin/activate
python app.py api
# API: http://127.0.0.1:8000; docs: http://127.0.0.1:8000/docs
```

Terminal 2:

```bash
cd web
npm run dev
# React: http://127.0.0.1:5173
```

Vite proxies `/api` requests to Python. No browser CORS workaround is necessary.
After changing React code, run `cd web && npm run build` before using the one-process
production launch again. Do not run Gradio and React on port 7860 simultaneously.

## Modules for the team

```text
app.py                      Main entry point (web/ui/api/grade/doctor/gradio)
api.py                      FastAPI routes, bounded job queue, readiness and history
backend.py                  Grading service, rules loading and report persistence
web/src/main.jsx            React application and JSON API integration
web/src/styles.css          Responsive interface styling
web/package-lock.json       Locked frontend dependencies
scripts/setup.sh            One-time Python + React setup
scripts/start.sh            Start frontend and backend together
rules/add.json              Editable tests, weights, thresholds and prompts
prompts/evaluator.txt        Evaluator system instructions
requirements.txt            Commented Python dependency list
sandbox/                    Docker image + bounded compiler/runtime worker
grader/coordinator.py       Sanity checks, dispatch, scoring and verdict cache
grader/analyzers/           Nine independent metric analyzers
frontend.py                 Optional legacy Gradio interface
examples/                   Correct, incorrect, hanging and crashing C samples
tests/                      Unit, API, Docker and Ollama end-to-end checks
data/                       Runtime reports and verdict cache (gitignored)
docs/                       Design report, API guide and validation record
```

## Backend JSON contract

`POST /api/evaluations` accepts a JSON object with `filename`, `source` and `rules`.
It returns HTTP 202 and a job `id`. Poll `GET /api/evaluations/{id}` for `queued`,
`running`, `complete`, or `error`. A completed job contains `report` and `text`.

The report follows the assignment: `submission`, `rules_hash`, `grade`,
`first_pass`, `metrics`, `flags`, `usefulness_limitations`, and `tool_versions`.
Each metric contains score, weight, contribution, evidence and feedback. The full
assignment-style JSON remains inside `report`; the job wrapper is only transport.

Other endpoints: `GET /api/rules`, `GET /api/health`, `GET /api/reports` and
`GET /api/reports/{evaluation_id}/{filename}`. Interactive API docs: `/docs`.

## Scoring and limits

Correctness has 20% weight; syntax, structure, modularity, edge cases, complexity,
memory safety, readability and originality each have 10%. Weights must total 1.
The final grade is `100 * sum(weight * score)`.

Ollama independently reviews structure, modularity, complexity and readability
using explicit rubric anchors, temperature 0 and seed 42. Compiler/test/sanitizer
facts cannot be overridden by model opinion. JSON responses and source references
are validated. Model output is never executed.

Compilation/smoke failures skip execution metrics at zero credit and preserve
source reviews. Tool/model failures produce `grade: null`, not a fabricated score.
Originality is an advisory local-corpus comparison and cannot prove copying or
LLM authorship. Use `--corpus corpus` with saved peer/web/LLM reference `.c` files.

The built-in arithmetic oracle generates integer boundaries and reproducible
random cases. The example requires the mathematical sum of int32 inputs, so
`2147483647 1` must produce `2147483648`, not undefined signed-C wraparound.
For other problems, supply instructor test cases and a suitable trusted oracle.

Normal runs have time/memory/pid/output limits, no network or host mounts and a
read-only container root. The supervisor uses only SETUID/SETGID/KILL capabilities
and drops compiler/student children to an unprivileged UID. Sanitizer runs use a
separate memory budget because ASan cannot use the normal small address-space cap.
Docker is not a substitute for a hardened VM boundary for hostile public tenants.

Limits: one 12 KB source file, 100 instructor cases, 50 generated random cases,
20 metrics, and 20 local reference files. Web rules require inline tests;
external `.in/.out` pairs under `testset_dir` are supported by the CLI.
The API accepts one running and one waiting job; job states are bounded to 50.

## Reproducibility

Completed verdicts are cached by source, effective rules/tests, corpus, prompts,
grader implementation, image ID and model digest/version. Keep this cache and
runtime fixed for a class cohort. Cache replay preserves the grade. Temperature
zero does not guarantee identical fresh inference across machines or versions,
and borderline timeouts can vary. The contract is persisted verdict replay, not
a universal proof of independent recomputation. See `docs/REPORT.md` for limits.

## Tests and sample reports

```bash
source .venv/bin/activate
python -m unittest discover -s tests -v
RUN_DOCKER_TESTS=1 RUN_E2E_TESTS=1 python -m unittest discover -s tests -v
python run_samples.py
```

`run_samples.py` creates genuine sample evaluations in `data/reports` and an index
at `data/sample-index.json`. No invented model grades are bundled. Unit/API tests
use explicitly named test doubles. See `docs/VALIDATION.md` for actual verification.

## Troubleshooting

- **Old interface still visible:** stop the previous Gradio process, extract the
  updated project, run setup, and start `bash scripts/start.sh`.
- **Port in use:** stop that instance or use `--port 7861`.
- **Frontend missing:** run `cd web && npm ci && npm run build`.
- **Docker/image missing:** check permissions and rebuild `sandbox/`.
- **Ollama unavailable:** start its service and pull the model named in the rules.
- **Incomplete evaluation:** read each metric error, fix the service, then rerun.
- **Context budget exceeded:** shorten source/rules or increase `llm.num_ctx` with
  sufficient local model memory. The evaluator never silently truncates source.

Primary documentation: https://fastapi.tiangolo.com/ · https://vite.dev/guide/ ·
https://react.dev/ · https://docs.ollama.com/api/chat ·
https://docs.ollama.com/capabilities/structured-outputs ·
https://docs.docker.com/engine/containers/run/
