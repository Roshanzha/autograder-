"""ASan/UBSan specialist; absence of diagnostics is not proof of memory safety."""
from .base import Analyzer, evaluate_cases, passed
from ..models import Result


class MemorySafetyAgent(Analyzer):
    execution_based = True

    def analyze(self, ctx, params):
        build = ctx.sandbox.compile(ctx.source, sanitize=True)
        binary = build.pop("binary", None)
        if not passed(build) or not binary:
            return Result(status="error", feedback="Sanitizer build failed.", evidence=build)
        result = evaluate_cases(ctx, ctx.rules.tests + ctx.edges, binary=binary, sanitize=True)
        result.feedback += " ASan/UBSan checks cover only executed paths. Instrumented memory cap is separate."
        result.evidence["sanitizer_memory_mb"] = ctx.rules.sanitizer_memory_mb
        return result
