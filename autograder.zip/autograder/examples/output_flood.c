#include <stdio.h>
int main(void) { for (;;) puts("output flood"); }
