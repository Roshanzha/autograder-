"""Opt-in real Docker tests: RUN_DOCKER_TESTS=1 python -m unittest discover -s tests.

These tests intentionally do not depend on subjective LLM scores.
"""
import os
from pathlib import Path
import unittest
from grader.files import load_rules
from grader.sandbox import DockerSandbox

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(os.getenv("RUN_DOCKER_TESTS") == "1", "Requires Ubuntu Docker sandbox")
class DockerIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sandbox = DockerSandbox(os.getenv("AUTOGRADER_IMAGE", "autograder-sandbox:1"))
        cls.sandbox.identity()
        cls.rules = load_rules(ROOT / "rules/add.json")

    def build(self, name, **kwargs):
        return self.sandbox.compile((ROOT / "examples" / name).read_text(), **kwargs)

    def test_correct_overflow_boundary(self):
        build = self.build("add_correct.c")
        result = self.sandbox.run(build["binary"], "2147483647 1\n", self.rules)
        self.assertEqual(result["stdout"], "2147483648\n")
        self.assertEqual(result["returncode"], 0)

    def test_compile_error(self):
        self.assertNotEqual(self.build("compile_error.c")["returncode"], 0)

    def test_timeout(self):
        result = self.sandbox.run(self.build("infinite.c")["binary"], "", self.rules)
        self.assertEqual(result["status"], "timeout")

    def test_crash(self):
        result = self.sandbox.run(self.build("crash.c")["binary"], "", self.rules)
        self.assertNotEqual(result["returncode"], 0)

    def test_output_cap(self):
        result = self.sandbox.run(self.build("output_flood.c")["binary"], "", self.rules)
        self.assertEqual(result["status"], "output_limit")
        self.assertLessEqual(len(result["stdout"]), 32768)

    def test_ubsan_detects_signed_overflow(self):
        build = self.build("add_original.c", sanitize=True)
        result = self.sandbox.run(build["binary"], "2147483647 1\n", self.rules, sanitize=True)
        self.assertNotEqual(result["returncode"], 0)
        self.assertIn("overflow", result["stderr"])

    def test_memory_limit(self):
        source = '#include <stdlib.h>\nint main(void){void *p=malloc(128UL*1024*1024); return p ? 1 : 0;}'
        build = self.sandbox.compile(source)
        result = self.sandbox.run(build["binary"], "", self.rules)
        self.assertEqual(result["returncode"], 0)

    def test_child_is_unprivileged_and_cannot_forge_protocol(self):
        source = '#include <unistd.h>\n#include <fcntl.h>\nint main(void){if(getuid()!=65534)return 1; int fd=open("/proc/1/fd/1",O_WRONLY);return fd<0?0:2;}'
        build = self.sandbox.compile(source)
        result = self.sandbox.run(build["binary"], "", self.rules)
        self.assertEqual(result["returncode"], 0)
