"""Linux-only worker inside Docker. Never run this worker directly on the host.

Each container handles exactly one compile or execution request, then disappears.
The host receives bounded JSON; student stdout is never mixed into the protocol.
"""
import base64
import json
import math
import os
from pathlib import Path
import resource
import selectors
import signal
import subprocess
import sys
import time

OUTPUT_LIMIT = 32768


def run_bounded(command, stdin, timeout, memory_mb=None):
    """Kill the entire process group on timeout/output overflow; cap files and CPU."""
    def limits():
        # Prevent student processes from signaling or accessing supervisor FDs.
        os.setgroups([])
        os.setgid(65534)
        os.setuid(65534)
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        resource.setrlimit(resource.RLIMIT_FSIZE, (4 * 1024**2, 4 * 1024**2))
        resource.setrlimit(resource.RLIMIT_CPU, (math.ceil(timeout) + 1, math.ceil(timeout) + 1))
        if memory_mb:
            limit = memory_mb * 1024**2
            resource.setrlimit(resource.RLIMIT_AS, (limit, limit))

    # A file input avoids deadlock when the child never reads stdin.
    Path("/tmp/input").write_bytes(stdin.encode())
    env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C", "TMPDIR": "/tmp",
           "ASAN_OPTIONS": "detect_leaks=1:halt_on_error=1:exitcode=86",
           "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=0:exitcode=87"}
    started = time.monotonic()
    with open("/tmp/input", "rb") as input_file:
        process = subprocess.Popen(command, stdin=input_file, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True,
                                   preexec_fn=limits, env=env)
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ, "stdout")
        selector.register(process.stderr, selectors.EVENT_READ, "stderr")
        buffers = {"stdout": bytearray(), "stderr": bytearray()}
        status = "exited"
        try:
            while selector.get_map():
                if time.monotonic() - started > timeout:
                    status = "timeout"
                    break
                for key, _ in selector.select(0.02):
                    chunk = os.read(key.fileobj.fileno(), 4096)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    buffer = buffers[key.data]
                    room = OUTPUT_LIMIT - len(buffer)
                    buffer.extend(chunk[:room])
                    if len(chunk) > room:
                        status = "output_limit"
                        break
                if status != "exited":
                    break
            # The process may close stdout/stderr but continue computing.
            if status == "exited":
                try:
                    process.wait(timeout=max(0.01, timeout - (time.monotonic() - started)))
                except subprocess.TimeoutExpired:
                    status = "timeout"
        finally:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait()
            selector.close()
            process.stdout.close()
            process.stderr.close()
        return {"status": status, "returncode": process.returncode,
                **{k: bytes(v).decode("utf-8", errors="replace") for k, v in buffers.items()}}


def main():
    request = json.loads(sys.stdin.buffer.read(3 * 1024**2))
    action = request["action"]
    if action == "version":
        result = {"gcc": subprocess.check_output(["gcc", "-dumpfullversion"], text=True).strip()}
    elif action == "compile":
        Path("/tmp/main.c").write_text(request["source"], encoding="utf-8")
        flags = ["-std=c11", "-Wall", "-Wextra", "-Wpedantic"]
        if request.get("strict"):
            flags.append("-Werror")
        if request.get("sanitize"):
            flags += ["-O1", "-g", "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
                      "-fno-sanitize-recover=all", "-fno-pie", "-no-pie"]
        else:
            flags += ["-O2"]
        result = run_bounded(["gcc", *flags, "/tmp/main.c", "-o", "/tmp/program"], "", 20)
        if result["returncode"] == 0 and result["status"] == "exited":
            executable = Path("/tmp/program").read_bytes()
            if len(executable) > 1024 * 1024:
                result.update(status="binary_size_limit", returncode=1)
            else:
                result["binary"] = base64.b64encode(executable).decode()
    elif action == "run":
        binary = Path("/tmp/program")
        binary.write_bytes(base64.b64decode(request["binary"], validate=True))
        binary.chmod(0o755)
        # ASan reserves a huge virtual address range; its physical memory is capped
        # by Docker instead of RLIMIT_AS. Ordinary runs have both limits.
        result = run_bounded([str(binary)], request["input"], request["time_limit_s"],
                             None if request.get("sanitize") else request["memory_limit_mb"])
    else:
        raise ValueError("Unknown worker action")
    print(json.dumps(result, ensure_ascii=True))


if __name__ == "__main__":
    main()
