"""Reproducible counterexample generation using a trusted Python arithmetic oracle."""
import random
from .base import Analyzer, evaluate_cases
from ..models import Result, TestCase


def generate_edges(rules):
    if rules.oracle == "none":
        return []
    # The contract is int32 inputs with a mathematical sum (up to 33 signed bits).
    low, high = -(2**31), 2**31 - 1
    pairs = [(0, 0), (-7, -5), (high, 1), (low, -1), (high, high),
             (low, low), (low, high), (1, -1)]
    rng = random.Random(rules.llm.seed)
    pairs += [(rng.randint(low, high), rng.randint(low, high))
              for _ in range(rules.generated_cases)]
    return [TestCase(name=f"generated-{i:03}", input=f" {a}\t{b}\n",
                     expected=f"{a+b}\n") for i, (a, b) in enumerate(pairs)]


class EdgeCaseAgent(Analyzer):
    execution_based = True

    def analyze(self, ctx, params):
        cases = ctx.edges + [TestCase.model_validate(c) for c in params.get("cases", [])]
        if not cases:
            return Result(status="error", feedback="Configure an oracle or explicit edge cases.")
        return evaluate_cases(ctx, cases)
