"""Offline comparison against instructor-provided peer, web and LLM exemplars.

Similarity is a review flag, never proof of copying or reliable LLM detection.
"""
import difflib
import re
from .base import Analyzer
from ..models import Result


def tokens(source):
    # Keep literals intact while removing comments; do not erase // inside strings.
    pattern = r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|//[^\n]*|/\*[\s\S]*?\*/|[A-Za-z_]\w*|\d+|[^\s]'
    return [t for t in re.findall(pattern, source) if not t.startswith(("//", "/*"))]


class OriginalityAgent(Analyzer):
    def analyze(self, ctx, params):
        threshold = float(params.get("flag_threshold", 0.85))
        if not 0 <= threshold <= 1:
            raise ValueError("flag_threshold must be in [0,1]")
        target = tokens(ctx.source)
        matches = sorted([
            {"reference": name, "similarity": difflib.SequenceMatcher(
                None, target, tokens(source), autojunk=False).ratio()}
            for name, source in ctx.corpus.items()], key=lambda x: (-x["similarity"], x["reference"]))
        flagged = bool(matches and matches[0]["similarity"] >= threshold)
        # Default is advisory; instructor may explicitly choose a flag score.
        score = float(params.get("flag_score", 1)) if flagged else 1.0
        return Result(score=score, feedback=("Similar code found; human review required." if flagged
                      else "No threshold match in the configured corpus; authorship remains unknown."),
                      evidence={"flagged": flagged, "threshold": threshold, "matches": matches[:5],
                                "corpus_files": len(matches), "llm_authorship": "not determinable",
                                "online_search": "not performed; use locally saved reference code"})
