import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Development uses one browser origin; API calls are proxied to Python.
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, strictPort: true, proxy: { '/api': 'http://127.0.0.1:8000' } },
  build: { outDir: 'dist', sourcemap: false },
});
