"""Source reasoning avoids misleading timing-curve fits for constant-size input."""
from .rubric import RubricAgent


class ComplexityAgent(RubricAgent):
    role = "asymptotic complexity: estimate time and auxiliary space against required bounds"
    execution_based = True  # Respect the assignment's smoke-failure dispatch policy.
