"""Sanity sweep -> independent specialists -> deterministic weighted aggregation."""
import json
import re
from pathlib import Path
from .analyzers import REGISTRY
from .analyzers.base import Context, passed
from .analyzers.edges import generate_edges
from .files import atomic_json, digest
from .models import Result
from .impact import USEFULNESS, LIMITATIONS


def aggregate(metrics):
    """Missing evidence never silently becomes a perfect score or a zero grade."""
    incomplete = any(m["status"] == "error" for m in metrics)
    points = sum(m["contribution"] for m in metrics)
    return None if incomplete else round(points, 4), round(points, 4)


def evaluate(source, rules, sandbox, llm, prompt, corpus=None, cache_dir=None):
    unknown = {m.analyzer for m in rules.metrics} - REGISTRY.keys()
    if unknown:
        raise ValueError(f"Unknown analyzers: {sorted(unknown)}")
    corpus = corpus or {}
    # Resolve runtime identity before consulting the cache so a model/image change
    # cannot accidentally reuse a grade produced under a different environment.
    identity = {"sandbox": sandbox.identity(), "llm": llm.identity()}
    implementation = {p.relative_to(Path(__file__).parent).as_posix(): p.read_text(encoding="utf-8")
                      for p in sorted(Path(__file__).parent.rglob("*.py"))}
    key = digest({"source": source, "rules": rules.model_dump(), "corpus": corpus,
                  "prompt": prompt, "identity": identity, "implementation": implementation})
    cache = Path(cache_dir) / (key + ".json") if cache_dir else None
    if cache and cache.exists():
        report = json.loads(cache.read_text(encoding="utf-8"))
        report["cache_hit"] = True
        return report

    build = sandbox.compile(source)
    binary = build.pop("binary", None)
    compiled = passed(build) and binary is not None
    smoke = sandbox.run(binary, rules.tests[0].input, rules) if compiled else None
    smoke_ok = smoke is not None and passed(smoke)
    flags = []
    if smoke and smoke["status"] == "timeout":
        flags.append("suspected_infinite_loop")
    if not compiled:
        flags.append("compilation_failed")
    elif not smoke_ok:
        flags.append("smoke_failed")
    # These patterns are advisory only: macros and alternative I/O are valid C.
    static_sanity = {"main_pattern": bool(re.search(r"\bmain\s*\(", source)),
                     "reader_pattern": bool(re.search(r"\b(scanf|fgets|getchar|read)\s*\(", source)),
                     "writer_pattern": bool(re.search(r"\b(printf|puts|putchar|write)\s*\(", source)),
                     "return_pattern": bool(re.search(r"\breturn\b", source))}
    ctx = Context(source, rules, sandbox, llm, prompt, binary, build, corpus, generate_edges(rules))
    metrics = []
    for metric in rules.metrics:
        agent = REGISTRY[metric.analyzer]()
        if agent.execution_based and not smoke_ok:
            result = Result(score=0, status="skipped", feedback="Execution prerequisite failed; configured weight earns zero.",
                            evidence={"reason": "compilation_or_smoke_failed",
                                      "input": rules.tests[0].input,
                                      "expected": rules.tests[0].expected, "smoke": smoke})
        else:
            try:
                result = agent.analyze(ctx, metric.params)
            except Exception as exc:
                # Preserve other specialists' findings without hiding infrastructure errors.
                result = Result(status="error", feedback=f"{type(exc).__name__}: {exc}")
        item = result.model_dump()
        item.update(name=metric.name, analyzer=metric.analyzer, weight=metric.weight,
                    contribution=round(100 * metric.weight * (result.score or 0), 6))
        metrics.append(item)
        if result.evidence.get("flagged"):
            flags.append("similarity_review_required")
    grade, earned = aggregate(metrics)
    report = {"evaluation_id": key, "source_hash": digest(source),
              "rules_hash": "sha256:" + digest(rules.model_dump()), "problem": rules.problem,
              "grade": grade, "earned_points": earned,
              "status": "incomplete" if grade is None else ("partial" if not smoke_ok else "complete"),
              "cache_hit": False, "first_pass": {"compiled": compiled, "smoke_ok": smoke_ok,
              "suspected_infinite_loop": "suspected_infinite_loop" in flags,
              "compilation": build, "smoke": smoke, "static_sanity": static_sanity},
              "metrics": metrics, "flags": flags, "runtime_identity": identity,
              "tool_versions": {"gcc": identity["sandbox"].get("gcc", "unknown"),
                                "ollama": identity["llm"].get("ollama_version", "unknown")},
              "llm_settings": rules.llm.model_dump(),
              "reproducibility": "Cached verdicts replay exactly for the same input and runtime identity. Fresh LLM/runtime evaluations can vary.",
              "rules_snapshot": rules.model_dump(),
              "usefulness_limitations": {"usefulness": USEFULNESS, "limitations": LIMITATIONS}}
    # Failed services must be retried on the next request, not frozen in the cache.
    if cache and grade is not None:
        atomic_json(cache, report)
    return report
