# Validation record — React/API version

## Passed on the creation host

- React production build: Vite 7.3.7; bundled assets generated in `web/dist`.
- Python tests: **43 discovered, 34 passed, 9 skipped**.
- API tests cover real HTTP routes: accepted background job lifecycle, report JSON,
  rules loading, invalid weights, unsafe filenames, request-size limit, cross-origin
  write rejection, platform error, missing reports/jobs and visible worker failures.
- Existing grader and frontend/backend contract tests still pass.
- FastAPI served the built React page with HTTP 200 on a local preview port.
- Browser verification: source/rubric render, editable rules loaded from Python,
  invalid JSON/rubric disables confirmation, navigation between evaluation/rules/
  past reports, and an actual backend platform error displayed in React.
- A screenshot of the rendered React interface is supplied with the deliverables.

The API lifecycle tests intentionally use fake grader/model implementations.
They verify integration and validation, not real C execution or model accuracy.

## Not executed here

Creation host: Windows. Docker and Ollama are unavailable here, so eight real
Docker integration tests and one real Ollama/Docker end-to-end test remain skipped.
Successful actual C grading, sanitizer behavior and model verdicts require Ubuntu
acceptance testing. No fabricated model scores or sample grading outputs are bundled.

## Ubuntu acceptance

```bash
bash scripts/setup.sh
docker build -t autograder-sandbox:1 sandbox/
ollama pull qwen2.5-coder:7b
.venv/bin/python app.py doctor
RUN_DOCKER_TESTS=1 RUN_E2E_TESTS=1 .venv/bin/python -m unittest discover -s tests -v
.venv/bin/python run_samples.py
bash scripts/start.sh
```

Open http://127.0.0.1:7860, upload both original and corrected samples, and verify
real feedback, failed inputs/expected outputs, JSON/TXT downloads and saved history.
All 43 tests should pass with no skips after a successful target-host setup.
