"""Deterministic oracle-output comparisons, independent of LLM opinion."""
from .base import Analyzer, evaluate_cases


class CorrectnessAgent(Analyzer):
    execution_based = True

    def analyze(self, ctx, params):
        return evaluate_cases(ctx, ctx.rules.tests)
