Put up to 20 reference `.c` files here (at most 12 KB each). Keep the evaluated
submission outside this folder. Use names such as `peer_01.c`, `web_example_01.c`,
or `llm_example_01.c`; maintain provenance/permission notes separately.

Run with `--corpus corpus` to enable comparisons. No reference code is bundled:
an empty corpus means no comparison coverage, not proof of originality.
