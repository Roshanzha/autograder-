"""Instructor frontend: C upload + editable rules JSON -> feedback + result JSON."""
from pathlib import Path
import tempfile
from backend import grade, ROOT
from grader.files import read_text
from grader.models import Rules
from grader.reporting import as_text


def evaluate_submission(source_file, rules_json, corpus=None):
    """Validate the editor contents before invoking the backend service.

    UI rules are self-contained JSON. The CLI still supports external test pairs.
    The temporary rules file is removed after the backend finishes grading.
    """
    if not source_file:
        raise ValueError("Choose a .c source file first.")
    rules = Rules.model_validate_json(rules_json)
    if rules.testset_dir:
        raise ValueError("For the UI, put cases directly in tests; external testset_dir is CLI-only.")
    with tempfile.TemporaryDirectory(prefix="autograder-rules-") as temporary:
        rules_path = Path(temporary) / "rules.json"
        rules_path.write_text(rules.model_dump_json(indent=2), encoding="utf-8")
        report, paths = grade(source_file, rules_path, corpus)
    return report, paths


def launch_ui(rules_path, corpus):
    # Lazy import keeps CLI and backend unit tests independent of Gradio.
    import gradio as gr

    def load_uploaded_rules(path):
        if not path:
            return read_text(Path(rules_path))
        raw = read_text(Path(path))
        Rules.model_validate_json(raw)
        return raw

    def submit(source_file, rules_json):
        try:
            report, paths = evaluate_submission(source_file, rules_json, corpus)
            score = report["grade"]
            heading = (f"Grade: {score:.2f} / 100" if score is not None else "Evaluation incomplete")
            return heading, as_text(report), report, list(paths)
        except Exception as exc:
            raise gr.Error(str(exc)) from exc

    with gr.Blocks(title="C Program AutoGrader") as demo:
        gr.Markdown("# C Program AutoGrader\nUpload C code, configure instructor rules in JSON, "
                    "and receive a grade with evidence from specialist agents.")
        gr.Markdown("Local instructor interface. Reports include test inputs and expected answers.")
        with gr.Row():
            source = gr.File(label="1. Student C submission", file_types=[".c"], type="filepath")
            uploaded_rules = gr.File(label="2. Optional instructor rules JSON", file_types=[".json"], type="filepath")
        with gr.Accordion("View or edit grading rules (JSON)", open=True):
            rules_editor = gr.Code(value=read_text(Path(rules_path)), language="json",
                                   label="Rules sent to the backend", interactive=True, lines=18)
        uploaded_rules.change(load_uploaded_rules, uploaded_rules, rules_editor)
        button = gr.Button("3. Evaluate submission", variant="primary")
        summary = gr.Textbox(label="Overall grade", interactive=False)
        with gr.Tab("Feedback report"):
            feedback = gr.Textbox(label="Per-metric feedback and counterexamples", lines=22, interactive=False)
        with gr.Tab("Backend JSON report"):
            json_report = gr.JSON(label="Assignment-style JSON response")
        downloads = gr.File(label="Download JSON and text reports", file_count="multiple")
        button.click(submit, [source, rules_editor], [summary, feedback, json_report, downloads],
                     concurrency_limit=1)
    demo.queue(default_concurrency_limit=1, max_size=8)
    demo.launch(server_name="127.0.0.1", share=False, max_file_size="1mb",
                allowed_paths=[str(ROOT / "data/reports")])
