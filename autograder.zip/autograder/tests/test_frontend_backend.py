"""Frontend/backend contract tests without launching Gradio or real services."""
from contextlib import nullcontext
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import backend
import frontend
from grader.coordinator import evaluate
from grader.files import load_rules
from grader.reporting import save_report
from test_unit import FakeSandbox, FakeLLM, ROOT


class FrontendBackendTests(unittest.TestCase):
    def setUp(self):
        self.rules = load_rules(ROOT / "rules/add.json")

    def test_frontend_passes_edited_json_to_backend(self):
        self.rules.memory_limit_mb = 128
        def inspect(source, rules_path, corpus):
            self.assertEqual(load_rules(rules_path).memory_limit_mb, 128)
            return {"grade": 75}, ("result.json", "result.txt")
        with patch.object(frontend, "grade", side_effect=inspect):
            report, paths = frontend.evaluate_submission("sample.c", self.rules.model_dump_json())
        self.assertEqual(report["grade"], 75)

    def test_frontend_rejects_invalid_weights_before_backend(self):
        data = self.rules.model_dump()
        data["metrics"][0]["weight"] = .9
        with patch.object(frontend, "grade") as grade:
            with self.assertRaises(ValueError):
                frontend.evaluate_submission("sample.c", json.dumps(data))
            grade.assert_not_called()

    def test_frontend_rejects_external_test_path(self):
        self.rules.testset_dir = "tests/add"
        with self.assertRaisesRegex(ValueError, "CLI-only"):
            frontend.evaluate_submission("sample.c", self.rules.model_dump_json())

    def test_backend_reports_assignment_fields_and_downloads(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "prompts").mkdir()
            (root / "prompts/evaluator.txt").write_text("test prompt")
            with patch.object(backend, "ROOT", root), \
                 patch.object(backend, "grading_lock", return_value=nullcontext()), \
                 patch.object(backend, "DockerSandbox", return_value=FakeSandbox()), \
                 patch.object(backend, "OllamaClient", return_value=FakeLLM()):
                report, paths = backend.grade(ROOT / "examples/add_original.c", ROOT / "rules/add.json")
            required = {"submission", "rules_hash", "grade", "first_pass", "metrics", "flags",
                        "usefulness_limitations", "tool_versions"}
            self.assertTrue(required <= report.keys())
            self.assertTrue(report["rules_hash"].startswith("sha256:"))
            self.assertIn("suspected_infinite_loop", report["first_pass"])
            self.assertEqual(Path(paths[0]).name, "add_original.json")
            saved = json.loads(Path(paths[0]).read_text())
            self.assertEqual(saved, report)
            self.assertTrue(Path(paths[1]).exists())

