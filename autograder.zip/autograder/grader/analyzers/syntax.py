"""Compiler specialist: a separate strict compilation measures diagnostic hygiene."""
from .base import Analyzer, passed
from ..models import Result


class SyntaxAgent(Analyzer):
    def analyze(self, ctx, params):
        result = ctx.sandbox.compile(ctx.source, strict=True)
        result.pop("binary", None)
        return Result(score=float(passed(result)), evidence=result,
                      feedback="Strict C11 compilation passed." if passed(result)
                      else "Strict C11 compilation failed; inspect compiler diagnostics.")
