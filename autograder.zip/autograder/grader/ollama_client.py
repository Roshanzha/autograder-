"""Local-only Ollama transport; model output is validated and never executed."""
import json
from urllib.parse import urlparse
import requests
from .models import Review


class OllamaClient:
    def __init__(self, settings, base_url="http://127.0.0.1:11434"):
        url = urlparse(base_url)
        if url.scheme != "http" or url.hostname not in {"localhost", "127.0.0.1", "::1"}:
            raise ValueError("Ollama must use a local loopback HTTP endpoint")
        self.settings, self.base_url = settings, base_url.rstrip("/")
        self.session = requests.Session()
        self.session.trust_env = False  # Never forward local code through proxy settings.

    def request(self, method, endpoint, **kwargs):
        response = self.session.request(method, self.base_url + endpoint,
                                        timeout=(5, 240), allow_redirects=False, **kwargs)
        response.raise_for_status()
        if response.is_redirect:
            raise ValueError("Ollama redirects are not allowed")
        return response.json()

    def identity(self):
        models = self.request("GET", "/api/tags")["models"]
        wanted = self.settings.model
        match = next((m for m in models if m["name"] in {wanted, wanted + ":latest"}), None)
        if not match:
            raise RuntimeError(f"Local model missing. Run: ollama pull {wanted}")
        return {"model": match["name"], "digest": match["digest"],
                "ollama_version": self.request("GET", "/api/version")["version"]}

    def review(self, system, payload):
        # An independent conversation for each specialist prevents cross-agent contamination.
        user = json.dumps(payload, ensure_ascii=True)
        # Conservative character budget avoids silently truncating student code/rubrics.
        if len(system) + len(user) > self.settings.num_ctx - self.settings.num_predict - 1000:
            raise ValueError("Review exceeds conservative context budget; shorten source or raise num_ctx")
        response = self.request("POST", "/api/chat", json={
            "model": self.settings.model, "stream": False,
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
            "format": Review.model_json_schema(),
            "options": {"temperature": 0, "seed": self.settings.seed,
                        "num_ctx": self.settings.num_ctx,
                        "num_predict": self.settings.num_predict},
        })
        if response.get("done_reason") == "length":
            raise ValueError("Ollama response reached output limit")
        result = Review.model_validate_json(response["message"]["content"])
        if any(f.line > payload["line_count"] for f in result.findings):
            raise ValueError("Ollama cited a nonexistent source line")
        return result

