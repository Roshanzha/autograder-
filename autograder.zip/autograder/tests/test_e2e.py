"""Explicit opt-in test of the complete real model/container workflow."""
import os
from pathlib import Path
import unittest


@unittest.skipUnless(os.getenv("RUN_E2E_TESTS") == "1", "Requires Ubuntu, Docker and local Ollama")
class EndToEndTests(unittest.TestCase):
    def test_original_submission_and_replay(self):
        from app import grade, ROOT
        report, paths = grade(ROOT / "examples/add_original.c", ROOT / "rules/add.json")
        self.assertIsNotNone(report["grade"])
        self.assertTrue(all(Path(p).exists() for p in paths))
        correctness = next(m for m in report["metrics"] if m["name"] == "correctness")
        self.assertTrue(correctness["evidence"]["failing"])
        replay, _ = grade(ROOT / "examples/add_original.c", ROOT / "rules/add.json")
        self.assertTrue(replay["cache_hit"])
        self.assertEqual(report["grade"], replay["grade"])
