"""Docker boundary: isolated filesystem/network and unprivileged student children."""
import json
import subprocess
import threading
import time
import uuid


class DockerSandbox:
    def __init__(self, image="autograder-sandbox:1"):
        self.image = image

    def identity(self):
        try:
            data = subprocess.check_output(["docker", "image", "inspect", self.image],
                                           timeout=15, text=True)
            self.image = json.loads(data)[0]["Id"]  # Pin immutable ID for this evaluation.
            return {"image_id": self.image, **self.call({"action": "version"})}
        except (OSError, subprocess.SubprocessError) as exc:
            raise RuntimeError("Docker/image unavailable. Build sandbox/Dockerfile first.") from exc

    def command(self, name, memory):
        return ["docker", "run", "--rm", "-i", "--name", name, "--network=none",
                "--read-only", "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID", "--cap-add=KILL",
                "--security-opt=no-new-privileges:true",
                "--user=0:0", "--pids-limit=32", "--cpus=1",
                f"--memory={memory}m", f"--memory-swap={memory}m",
                "--ulimit=nofile=64:64", "--ulimit=core=0:0", "--log-driver=none",
                "--tmpfs=/tmp:rw,exec,nosuid,nodev,size=32m,mode=1777", self.image]

    def call(self, request):
        name = "autograder-" + uuid.uuid4().hex
        memory = request.get("memory_limit_mb", 512) if request["action"] == "run" else 512
        if request.get("sanitize"):
            memory = request.get("sanitizer_memory_mb", 512)
        try:
            code, stdout, stderr = bounded_process(self.command(name, memory), json.dumps(request))
            if code != 0:
                raise RuntimeError(f"Sandbox failed ({code}): {stderr[:1000]}")
            return json.loads(stdout)
        finally:
            # Killing the Docker client alone does not stop a detached container.
            subprocess.run(["docker", "rm", "-f", name], capture_output=True, timeout=10)

    def compile(self, source, strict=False, sanitize=False):
        return self.call({"action": "compile", "source": source,
                          "strict": strict, "sanitize": sanitize})

    def run(self, binary, text, rules, sanitize=False):
        return self.call({"action": "run", "binary": binary, "input": text,
                          "time_limit_s": rules.time_limit_s,
                          "memory_limit_mb": rules.memory_limit_mb,
                          "sanitizer_memory_mb": rules.sanitizer_memory_mb,
                          "sanitize": sanitize})


def bounded_process(command, payload, timeout=35):
    """Bound Docker output too, including unexpected protocol-level output."""
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE)
    buffers = [bytearray(), bytearray()]
    overflow = threading.Event()

    def drain(stream, buffer):
        while True:
            chunk = stream.read(4096)
            if not chunk:
                break
            room = 2 * 1024**2 - len(buffer)
            buffer.extend(chunk[:room])
            if len(chunk) > room:
                overflow.set()

    def feed():
        try:
            process.stdin.write(payload.encode())
            process.stdin.close()
        except (BrokenPipeError, OSError):
            pass

    threads = [threading.Thread(target=drain, args=(process.stdout, buffers[0]), daemon=True),
               threading.Thread(target=drain, args=(process.stderr, buffers[1]), daemon=True),
               threading.Thread(target=feed, daemon=True)]
    for thread in threads:
        thread.start()
    deadline = time.monotonic() + timeout
    try:
        while process.poll() is None:
            if overflow.is_set():
                raise RuntimeError("Sandbox protocol output exceeded 2 MB")
            if time.monotonic() >= deadline:
                raise TimeoutError("Docker operation exceeded host deadline")
            time.sleep(0.02)
    finally:
        if process.poll() is None:
            process.kill()
        process.wait()
        for thread in threads:
            thread.join(timeout=2)
        for stream in (process.stdin, process.stdout, process.stderr):
            if not stream.closed:
                stream.close()
    if overflow.is_set():
        raise RuntimeError("Sandbox protocol output exceeded 2 MB")
    return process.returncode, *(bytes(b).decode("utf-8", errors="replace") for b in buffers)
