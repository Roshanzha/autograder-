"""Fast tests with explicit test doubles; these do not claim real model accuracy."""
import copy
import json
from pathlib import Path
import tempfile
import sys
import unittest
from unittest.mock import patch
from pydantic import ValidationError
from grader.models import Rules, Review
from grader.files import load_rules, under
from grader.coordinator import evaluate, aggregate
from grader.analyzers.edges import generate_edges
from grader.analyzers.originality import tokens, OriginalityAgent
from grader.analyzers.base import Context
from grader.ollama_client import OllamaClient
from grader.sandbox import DockerSandbox, bounded_process
from grader.reporting import as_text

ROOT = Path(__file__).resolve().parents[1]


class FakeSandbox:
    def __init__(self, compile_ok=True, smoke_status="exited"):
        self.compile_ok, self.smoke_status = compile_ok, smoke_status
        self.calls = 0

    def identity(self):
        return {"image_id": "TEST_DOUBLE", "gcc": "TEST_DOUBLE"}

    def compile(self, source, **kwargs):
        self.calls += 1
        return {"status": "exited", "returncode": 0 if self.compile_ok else 1,
                "stdout": "", "stderr": "", **({"binary": "FAKE"} if self.compile_ok else {})}

    def run(self, binary, text, rules, **kwargs):
        self.calls += 1
        return {"status": self.smoke_status, "returncode": 0,
                "stdout": f"{sum(map(int, text.split()))}\n", "stderr": ""}


class FakeLLM:
    def identity(self):
        return {"model": "TEST_DOUBLE", "digest": "TEST_DOUBLE"}

    def review(self, system, payload):
        return Review(score=1, feedback="Test-double response, not an actual LLM review.",
                      findings=[], uncertainty="Test double")


class UnitTests(unittest.TestCase):
    def setUp(self):
        self.rules = load_rules(ROOT / "rules/add.json")
        self.source = (ROOT / "examples/add_correct.c").read_text()

    def evaluate(self, sandbox=None, llm=None, **kwargs):
        return evaluate(self.source, self.rules, sandbox or FakeSandbox(), llm or FakeLLM(),
                        "test prompt", **kwargs)

    def test_weights_reject_pdf_style_arithmetic_errors(self):
        data = self.rules.model_dump()
        data["metrics"][0]["weight"] = .3
        with self.assertRaises(ValidationError):
            Rules.model_validate(data)

    def test_duplicate_metric_names_rejected(self):
        data = self.rules.model_dump()
        data["metrics"][1]["name"] = data["metrics"][0]["name"]
        with self.assertRaises(ValidationError):
            Rules.model_validate(data)

    def test_nonzero_temperature_rejected(self):
        data = self.rules.model_dump()
        data["llm"]["temperature"] = .5
        with self.assertRaises(ValidationError):
            Rules.model_validate(data)

    def test_invalid_score_rejected(self):
        for score in [1.5, -1, float("nan")]:
            with self.assertRaises(ValidationError):
                Review(score=score, feedback="bad", findings=[], uncertainty="")

    def test_oracle_is_reproducible_and_wider_than_int32(self):
        a, b = generate_edges(self.rules), generate_edges(self.rules)
        self.assertEqual(a, b)
        self.assertIn("2147483648\n", [case.expected for case in a])
        self.assertEqual(len(a), 20)

    def test_full_dispatch_and_weighted_score(self):
        report = self.evaluate()
        self.assertEqual(report["grade"], 100)
        self.assertEqual(len(report["metrics"]), 9)

    def test_compile_failure_skips_execution_but_reviews_source(self):
        report = self.evaluate(FakeSandbox(compile_ok=False))
        metrics = {m["name"]: m for m in report["metrics"]}
        self.assertEqual(metrics["correctness"]["status"], "skipped")
        self.assertEqual(metrics["readability"]["status"], "ok")
        self.assertEqual(report["status"], "partial")
        self.assertIn("EXPECTED", as_text(report))

    def test_timeout_flags_and_skips(self):
        report = self.evaluate(FakeSandbox(smoke_status="timeout"))
        self.assertIn("suspected_infinite_loop", report["flags"])
        self.assertEqual(sum(m["status"] == "skipped" for m in report["metrics"]), 4)

    def test_llm_error_does_not_silently_grade(self):
        llm = FakeLLM()
        llm.review = lambda *args: (_ for _ in ()).throw(ValueError("invalid JSON"))
        report = self.evaluate(llm=llm)
        self.assertIsNone(report["grade"])
        self.assertEqual(report["status"], "incomplete")

    def test_cache_replay_and_input_invalidation(self):
        with tempfile.TemporaryDirectory() as directory:
            first = self.evaluate(cache_dir=directory)
            sandbox = FakeSandbox()
            second = self.evaluate(sandbox, cache_dir=directory)
            self.assertTrue(second["cache_hit"])
            self.assertEqual(first["grade"], second["grade"])
            self.assertEqual(sandbox.calls, 0)
            self.source += "\n/* changed */\n"
            third = self.evaluate(cache_dir=directory)
            self.assertNotEqual(first["evaluation_id"], third["evaluation_id"])

    def test_corpus_change_invalidates_cache(self):
        one = self.evaluate(corpus={})
        two = self.evaluate(corpus={"ref.c": self.source})
        self.assertNotEqual(one["evaluation_id"], two["evaluation_id"])
        self.assertIn("similarity_review_required", two["flags"])

    def test_unknown_analyzer_rejected(self):
        self.rules.metrics[0].analyzer = "arbitrary_import"
        with self.assertRaises(ValueError):
            self.evaluate()

    def test_path_traversal_rejected(self):
        with self.assertRaises(ValueError):
            under(ROOT, "../escape")

    def test_comment_tokens_preserve_string_literals(self):
        self.assertEqual(tokens('puts("https://example"); // ignored'),
                         ['puts', '(', '"https://example"', ')', ';'])

    def test_external_ollama_endpoint_rejected(self):
        with self.assertRaises(ValueError):
            OllamaClient(self.rules.llm, "https://example.com")

    def test_docker_has_no_mount_or_network(self):
        command = DockerSandbox().command("unit", 64)
        for flag in ["--network=none", "--read-only", "--cap-drop=ALL", "--memory=64m", "--memory-swap=64m"]:
            self.assertIn(flag, command)
        self.assertNotIn("--privileged", command)
        self.assertNotIn("-v", command)

    def test_wrong_output_preserves_counterexample(self):
        class WrongSandbox(FakeSandbox):
            def run(self, *args, **kwargs):
                result = super().run(*args, **kwargs)
                result["stdout"] = "wrong\n"
                return result
        report = self.evaluate(WrongSandbox())
        failure = report["metrics"][0]["evidence"]["failing"][0]
        self.assertEqual(failure["input"], "7 5\n")
        self.assertEqual(failure["expected"], "12\n")
        self.assertEqual(failure["got"], "wrong\n")

    def test_host_protocol_roundtrip(self):
        code, out, err = bounded_process([sys.executable, "-c", "import sys; print(sys.stdin.read())"], "hello")
        self.assertEqual(code, 0)
        self.assertEqual(out.strip(), "hello")

    def test_host_protocol_output_limit(self):
        with self.assertRaisesRegex(RuntimeError, "output exceeded"):
            bounded_process([sys.executable, "-c", "print('x' * (3*1024*1024))"], "")

    def test_host_protocol_timeout(self):
        with self.assertRaises(TimeoutError):
            bounded_process([sys.executable, "-c", "import time; time.sleep(5)"], "", timeout=.1)

    def test_llm_nonexistent_line_rejected(self):
        client = OllamaClient(self.rules.llm)
        fake = {"message": {"content": json.dumps({"score": .5, "feedback": "Issue",
                "findings": [{"line": 99, "explanation": "Made up"}], "uncertainty": ""})}}
        with patch.object(client, "request", return_value=fake):
            with self.assertRaisesRegex(ValueError, "nonexistent"):
                client.review("system", {"source": "int main(){}", "line_count": 1})


if __name__ == "__main__":
    unittest.main()
