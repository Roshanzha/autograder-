"""Machine-readable JSON and readable text share the same validated results."""
from pathlib import Path
import re
from .files import atomic_json


def as_text(report):
    grade = report["grade"]
    lines = [f"AutoGrader: {report['problem']}",
             f"Submission: {report.get('submission', '(not supplied)')}",
             f"Grade: {grade if grade is not None else 'INCOMPLETE'} / 100",
             f"Status: {report['status']}", f"Evaluation: {report['evaluation_id']}", ""]
    compilation = report["first_pass"]["compilation"]
    if compilation.get("stderr"):
        lines += ["Compiler diagnostics:", compilation["stderr"], ""]
    for metric in report["metrics"]:
        lines += [f"{metric['name']}: {metric['contribution']:.2f}/{100*metric['weight']:.2f} ({metric['status']})",
                  metric["feedback"]]
        if metric["evidence"].get("stderr"):
            lines.append(metric["evidence"]["stderr"])
        for finding in metric["evidence"].get("review", {}).get("findings", []):
            lines.append(f"  Line {finding['line']}: {finding['explanation']}")
        for failure in metric["evidence"].get("failing", []):
            lines += [f"  INPUT: {failure['input']!r}", f"  EXPECTED: {failure['expected']!r}",
                      f"  GOT: {failure['got']!r}",
                      f"  STATUS: {failure['status']}; exit={failure['returncode']}",
                      f"  DIAGNOSTIC: {failure['stderr']}"]
        if metric["status"] == "skipped":
            lines += [f"  INPUT: {metric['evidence']['input']!r}",
                      f"  EXPECTED: {metric['evidence']['expected']!r}"]
        lines.append("")
    lines += ["Flags: " + ", ".join(report["flags"]), report["reproducibility"]]
    for heading, examples in report["usefulness_limitations"].items():
        lines += ["", heading.upper()]
        lines += [f"{i}. {example}" for i, example in enumerate(examples, 1)]
    return "\n".join(lines)


def save_report(report, folder):
    # Keep each evaluation separate while retaining assignment-style add.json/add.txt names.
    folder = Path(folder) / report["evaluation_id"]
    folder.mkdir(parents=True, exist_ok=True)
    stem = re.sub(r"[^A-Za-z0-9_-]", "_", Path(report.get("submission", "report.c")).stem)[:80] or "report"
    json_path, text_path = folder / f"{stem}.json", folder / f"{stem}.txt"
    atomic_json(json_path, report)
    text_path.write_text(as_text(report), encoding="utf-8")
    return str(json_path), str(text_path)
