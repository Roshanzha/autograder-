# React frontend and Python backend

The default frontend is now React (`web/src/main.jsx`). `api.py` exposes FastAPI
JSON endpoints and serves the built React files from `web/dist`. `backend.py`
retains the grading service; `app.py` is the main entry point.

## Run

After installing Ubuntu, Docker, Ollama and Node.js 22.12+ prerequisites:

```bash
bash scripts/setup.sh
docker build -t autograder-sandbox:1 sandbox/
ollama pull qwen2.5-coder:7b
bash scripts/start.sh
```

Open http://127.0.0.1:7860. No separate frontend process is required after build.
For development use `python app.py api` and, in `web/`, `npm run dev`.

## API

- `GET /api/health`: actual service readiness and configured model.
- `GET /api/rules`: default self-contained JSON rules.
- `POST /api/evaluations`: `{filename, source, rules}`, returns HTTP 202 with job ID.
- `GET /api/evaluations/{id}`: real job state, with `report` and `text` on completion.
- `GET /api/reports`: saved report summaries, newest first (up to 50).
- `GET /api/reports/{evaluation_id}/{filename}`: a saved JSON or text report.

The report retains `submission`, `rules_hash`, `grade`, `first_pass`, `metrics`,
`flags`, `usefulness_limitations` and `tool_versions`. Extra audit fields include
`evaluation_id`, `source_hash`, `status`, `cache_hit`, `runtime_identity`,
`llm_settings`, `rules_snapshot`, and `reproducibility`.

A completed API job may contain an incomplete evaluation (`report.grade: null`)
if a specialist failed. Transport completion does not imply a successful grade.
An API job error contains an explicit error string. The UI does not invent scores.

Reports are saved as `data/reports/<evaluation-id>/<submission-stem>.json` and `.txt`.
Job IDs are ephemeral across server restarts; saved reports and verdict caches
persist. One grading job can run and one can wait. Further submissions receive 429.

## User interface

- **Evaluate code:** sample/file upload, filename and code editor, live rubric,
  evaluation button, real status, expandable metric feedback and backend JSON.
- **Grading rules:** editable JSON plus import/export. Rules need inline test cases.
- **Past evaluations:** load existing reports without regrading.
- **Setup:** live readiness checks and startup instructions.

The old Gradio interface is optional through `requirements-gradio.txt` and
`python app.py gradio`. It is not used by the React application.
