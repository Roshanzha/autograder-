#!/usr/bin/env bash
# One process serves the React build and Python API. Ctrl+C stops both.
set -euo pipefail
cd "$(dirname "$0")/.."
test -x .venv/bin/python || { echo 'Run bash scripts/setup.sh first.'; exit 1; }
test -f web/dist/index.html || { echo 'Missing React build. Run bash scripts/setup.sh.'; exit 1; }
exec .venv/bin/python app.py web "$@"
