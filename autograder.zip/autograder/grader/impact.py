"""Concrete benefits and failure modes included in every report."""
USEFULNESS = [
    "Teaching labs: grade 300 addition exercises with the same tests and show each student an overflow counterexample.",
    "Practice feedback: a student fixes an infinite loop and reruns the submission without waiting for office hours.",
    "Interview support: reviewers compare correctness and structure evidence across 50 candidates under one rubric.",
    "Copying triage: a 0.93 token-similarity match against a known reference narrows the instructor's manual review.",
]
LIMITATIONS = [
    "Finite tests: code hard-coding the known inputs can pass every supplied/generated case but fail a new valid pair; a perfect test score is not proof.",
    "LLM reasoning: a loop hidden behind a macro may be misclassified as O(1), or a clear one-letter mathematical variable may be unfairly penalized. Review deductions and calibrate on instructor-scored examples.",
    "Authorship ambiguity: two independent five-line addition solutions may exceed the similarity threshold, while renamed or rewritten copied code may evade it. LLM authorship and unseen web copying cannot be established.",
    "Runtime variability: a solution near the time/memory boundary may pass on one host and fail on another; ASan overhead may cause an instrumented-only failure. Cached replay preserves an existing verdict, not correctness across fresh environments.",
]
