"""Run the frontend, CLI evaluator or dependency checks from one entry point."""
import argparse
import os
from pathlib import Path
import sys
from backend import grade, ROOT
from grader.files import load_rules
from grader.ollama_client import OllamaClient
from grader.reporting import as_text
from grader.sandbox import DockerSandbox


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["grade", "ui", "web", "api", "gradio", "doctor"])
    parser.add_argument("submission", nargs="?")
    parser.add_argument("--rules", type=Path, default=ROOT / "rules/add.json")
    parser.add_argument("--corpus", type=Path)
    parser.add_argument("--port", type=int, default=None)
    args = parser.parse_args()
    try:
        if args.command in {"ui", "web", "api"}:
            import uvicorn
            if args.command != "api" and not (ROOT / "web/dist/index.html").exists():
                raise RuntimeError("Build the React frontend first: cd web && npm ci && npm run build")
            os.environ["AUTOGRADER_RULES"] = str(args.rules.resolve())
            if args.corpus:
                os.environ["AUTOGRADER_CORPUS"] = str(args.corpus.resolve())
            uvicorn.run("api:app", host="127.0.0.1", port=args.port or (8000 if args.command == "api" else 7860))
        elif args.command == "gradio":
            from frontend import launch_ui
            launch_ui(args.rules, args.corpus)
        elif args.command == "doctor":
            rules = load_rules(args.rules)
            print("Sandbox:", DockerSandbox(os.getenv("AUTOGRADER_IMAGE", "autograder-sandbox:1")).identity())
            print("Ollama:", OllamaClient(rules.llm, os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")).identity())
        else:
            if not args.submission:
                parser.error("grade requires a submission path")
            report, paths = grade(args.submission, args.rules, args.corpus)
            print(as_text(report))
            print("Saved:", *paths, sep="\n")
            return 2 if report["grade"] is None else 0
    except Exception as exc:
        print(f"Evaluation failed: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
