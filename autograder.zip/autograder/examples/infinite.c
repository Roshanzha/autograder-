int main(void) { for (;;) {} }
