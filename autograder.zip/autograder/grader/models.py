"""Validated contracts shared by the CLI, coordinator and specialist agents."""
from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)


class TestCase(StrictModel):
    name: str
    input: str = Field(max_length=8192)
    expected: str = Field(max_length=8192)


class Metric(StrictModel):
    name: str
    analyzer: str
    weight: float = Field(ge=0, le=1)
    params: dict[str, Any] = Field(default_factory=dict)


class LLMSettings(StrictModel):
    model: str = "qwen2.5-coder:7b"
    temperature: Literal[0] = 0
    seed: int = 42
    num_ctx: int = Field(default=16384, ge=8192, le=65536)
    num_predict: int = Field(default=2048, ge=256, le=4096)


class Rules(StrictModel):
    problem: str
    specification: str = Field(min_length=20, max_length=8000)
    time_limit_s: float = Field(default=1, ge=0.1, le=10)
    memory_limit_mb: int = Field(default=64, ge=32, le=512)
    sanitizer_memory_mb: int = Field(default=512, ge=256, le=1024)
    comparison: Literal["exact", "tokens"] = "exact"
    tests: list[TestCase] = Field(min_length=1, max_length=100)
    # External .in/.out pairs are optional and resolved under the rules directory.
    testset_dir: str | None = None
    oracle: Literal["add_two_int32", "none"] = "none"
    generated_cases: int = Field(default=12, ge=0, le=50)
    metrics: list[Metric] = Field(min_length=1, max_length=20)
    llm: LLMSettings = Field(default_factory=LLMSettings)

    @model_validator(mode="after")
    def check_weights(self):
        if abs(sum(m.weight for m in self.metrics) - 1) > 1e-9:
            raise ValueError("Metric weights must total 1.0; weights are never silently normalized.")
        if len({m.name for m in self.metrics}) != len(self.metrics):
            raise ValueError("Metric names must be unique.")
        return self


class Finding(StrictModel):
    line: int = Field(ge=1)
    explanation: str = Field(min_length=1, max_length=1000)


class Review(StrictModel):
    score: float = Field(ge=0, le=1)
    feedback: str = Field(min_length=1, max_length=3000)
    findings: list[Finding] = Field(max_length=20)
    uncertainty: str = Field(max_length=1000)


class Result(StrictModel):
    score: float | None = Field(default=None, ge=0, le=1)
    status: Literal["ok", "skipped", "error"] = "ok"
    feedback: str
    evidence: dict[str, Any] = Field(default_factory=dict)

