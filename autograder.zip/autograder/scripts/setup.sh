#!/usr/bin/env bash
# One-time project dependency setup. Docker/Ollama are system prerequisites.
set -euo pipefail
cd "$(dirname "$0")/.."
command -v node >/dev/null || { echo 'Install Node.js 22.12+ before continuing.'; exit 1; }
node -e 'const [a,b]=process.versions.node.split(".").map(Number); if(a<22 || (a===22 && b<12)) {console.error("Node.js 22.12+ required"); process.exit(1)}'
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
cd web
npm ci
npm run build
printf '\nReady. From the project folder run: bash scripts/start.sh\n'
