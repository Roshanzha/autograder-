"""Rule-driven C evaluation with local Ollama specialist agents."""
__version__ = "1.0.0"
