"""Readability specialist; naming and layout are evaluated with explicit anchors."""
from .rubric import RubricAgent


class ReadabilityAgent(RubricAgent):
    role = "readability: naming, whitespace, comments and clarity"
