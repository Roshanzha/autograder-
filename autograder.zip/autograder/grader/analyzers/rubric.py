"""Ollama specialist foundation; instructor rubrics remain outside application code."""
from .base import Analyzer
from ..models import Result, Review


class RubricAgent(Analyzer):
    role = "custom instructor-defined metric"

    def analyze(self, ctx, params):
        if not params.get("rubric"):
            raise ValueError("LLM-based metric requires a nonempty rubric")
        source_lines = ctx.source.splitlines()
        payload = {
            "metric": self.role, "specification": ctx.rules.specification,
            "rubric_and_thresholds": params, "line_count": len(source_lines),
            "source": "\n".join(f"{i}: {line}" for i, line in enumerate(source_lines, 1)),
            "compiler_evidence": ctx.compilation,
            "response_schema": Review.model_json_schema(),
        }
        review = ctx.llm.review(ctx.prompt, payload)
        return Result(score=review.score, feedback=review.feedback,
                      evidence={"review": review.model_dump(), "method": "Ollama rubric review"})
