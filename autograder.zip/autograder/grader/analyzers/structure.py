"""Structure specialist with its own conversation and instructor thresholds."""
from .rubric import RubricAgent


class StructureAgent(RubricAgent):
    role = "structure: nesting, cyclomatic complexity and function length"
