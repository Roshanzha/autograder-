#include <stdio.h>

/* Wider arithmetic preserves the mathematical sum of two signed 32-bit inputs. */
static long long add(long long left, long long right) {
    return left + right;
}

int main(void) {
    long long left, right;
    if (scanf("%lld %lld", &left, &right) != 2) {
        return 1;
    }
    printf("%lld\n", add(left, right));
    return 0;
}
