import React, { useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowDownToLine, ArrowRight, ArrowUpRight, Braces, Check, CheckCircle2, ChevronRight, CircleHelp, ClipboardCheck, Code2, Cpu, FileCode2, FileJson2, FolderClock, HardDrive, Layers3, LoaderCircle, Play, Plus, RefreshCw, ShieldCheck, SlidersHorizontal, Sparkles, Terminal, Upload, X, AlertCircle, Clock3 } from 'lucide-react';
import './styles.css';
const SAMPLE = '#include <stdio.h>\n\nint main(void) {\n    int a, b;\n    scanf("%d %d", &a, &b);\n    printf("%d\\n", a + b);\n    return 0;\n}\n';
const metricNames = {
  correctness: 'Correctness',
  syntax: 'Syntax & compilation',
  structure: 'Code structure',
  modularity: 'Modularity',
  logical: 'Edge cases',
  complexity: 'Time complexity',
  memory_safety: 'Memory safety',
  readability: 'Readability',
  originality: 'Originality'
};
const metricIcons = {
  correctness: CheckCircle2,
  syntax: Terminal,
  structure: Layers3,
  modularity: Braces,
  logical: Sparkles,
  complexity: Clock3,
  memory_safety: ShieldCheck,
  readability: Code2,
  originality: ClipboardCheck
};

// Keep transport in one place so server errors appear consistently in every view.
async function api(path, options) {
  const response = await fetch(`/api${path}`, options);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = data.detail;
    throw new Error(Array.isArray(detail) ? detail.map(e => `${e.loc?.slice(1).join('.')}: ${e.msg}`).join('; ') : detail || `Request failed (${response.status})`);
  }
  return data;
}
function download(content, name, type) {
  const url = URL.createObjectURL(new Blob([content], {
    type
  }));
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function App() {
  const [view, setView] = useState('evaluate');
  const [source, setSource] = useState(SAMPLE);
  const [filename, setFilename] = useState('add.c');
  const [rulesText, setRulesText] = useState('');
  const [health, setHealth] = useState(null);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState('');
  const [job, setJob] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [jobId, setJobId] = useState(() => sessionStorage.getItem('autograder-job'));
  const [report, setReport] = useState(null);
  const [textReport, setTextReport] = useState('');
  const [resultTab, setResultTab] = useState('feedback');
  const [history, setHistory] = useState([]);
  const [setupOpen, setSetupOpen] = useState(false);
  const [dragging, setDragging] = useState(false);
  const uploadRef = useRef();
  const rulesUploadRef = useRef();
  const resultsRef = useRef();
  const busy = Boolean(jobId) || submitting;
  let rules, rulesError;
  try {
    rules = JSON.parse(rulesText);
    if (!Array.isArray(rules.metrics) || !rules.metrics.length) throw new Error('Add a nonempty metrics array.');
    if (!rules.metrics.every(m => typeof m.weight === 'number' && Number.isFinite(m.weight) && m.weight >= 0 && m.weight <= 1)) throw new Error('Each weight must be a number between 0 and 1.');
    if (Math.abs(rules.metrics.reduce((total, m) => total + Number(m.weight), 0) - 1) > 1e-9) throw new Error('Metric weights must total 1.00 (100%).');
  } catch (e) {
    rulesError = e.message;
    rules = undefined;
  }
  async function checkHealth() {
    setChecking(true);
    try {
      setHealth(await api('/health'));
    } catch {
      setHealth({
        ready: false,
        disconnected: true
      });
    } finally {
      setChecking(false);
    }
  }
  async function refreshHistory() {
    try {
      setHistory(await api('/reports'));
    } catch (e) {
      setError(e.message);
    }
  }
  useEffect(() => {
    api('/rules').then(data => setRulesText(JSON.stringify(data, null, 2))).catch(e => setError(e.message));
    checkHealth();
    refreshHistory();
  }, []);

  // Poll actual queued/running/completed state, never simulated progress percentages.
  useEffect(() => {
    if (!jobId) return;
    let cancelled = false,
      timer;
    async function poll() {
      try {
        const data = await api(`/evaluations/${jobId}`);
        if (cancelled) return;
        setJob(data);
        if (data.status === 'complete' || data.status === 'error') {
          setJobId(null);
          sessionStorage.removeItem('autograder-job');
          if (data.status === 'error') setError(data.error);else {
            setReport(data.report);
            setTextReport(data.text);
            refreshHistory();
          }
        } else timer = setTimeout(poll, 1500);
      } catch (e) {
        if (!cancelled) {
          setError(e.message);
          setJobId(null);
          sessionStorage.removeItem('autograder-job');
        }
      }
    }
    poll();
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [jobId]);
  useEffect(() => {
    if (report) resultsRef.current?.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  }, [report]);
  async function loadSource(file) {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith('.c')) {
      setError('Please choose a C source file (.c).');
      return;
    }
    if (file.size > 12000) {
      setError('This evaluator supports a single C file up to 12 KB.');
      return;
    }
    setSource(await file.text());
    setFilename(file.name.replace(/[^A-Za-z0-9_.-]/g, '_'));
    setError('');
    setReport(null);
  }
  async function loadRules(file) {
    if (!file) return;
    if (file.size > 100000) {
      setError('Rules JSON must be under 100 KB.');
      return;
    }
    try {
      setRulesText(JSON.stringify(JSON.parse(await file.text()), null, 2));
      setError('');
    } catch {
      setError('The selected file is not valid JSON.');
    }
  }
  async function evaluate() {
    setError('');
    setReport(null);
    if (rulesError) {
      setError(`Check the grading rules: ${rulesError}`);
      return;
    }
    try {
      setSubmitting(true);
      const data = await api('/evaluations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          filename,
          source,
          rules
        })
      });
      setJob(data);
      setJobId(data.id);
      sessionStorage.setItem('autograder-job', data.id);
    } catch (e) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  }
  async function openReport(item) {
    try {
      const data = await api(`/reports/${item.id}/${item.file}`);
      const response = await fetch(`/api/reports/${item.id}/${item.file.replace(/\.json$/, '.txt')}`);
      setTextReport(response.ok ? await response.text() : 'Text report is unavailable.');
      setReport(data);
      setView('evaluate');
    } catch (e) {
      setError(e.message);
    }
  }
  const metrics = rules?.metrics || [];
  const lines = source.split('\n').length;
  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#" onClick={e => {
        e.preventDefault();
        setView('evaluate');
      }}><span className="brand-mark"><Braces size={23} /></span>AutoGrader<span className="brand-dot">.</span></a>
      <div className="workspace"><span className="workspace-avatar">C</span><div><strong>C Programming Lab</strong><small>Instructor workspace</small></div><span className="tiny-square">01</span></div>
      <p className="nav-label">WORKSPACE</p>
      <nav aria-label="Main navigation">
        {[['evaluate', FileCode2, 'Evaluate code'], ['rules', SlidersHorizontal, 'Grading rules'], ['reports', FolderClock, 'Past evaluations']].map(([id, Icon, label]) => <button key={id} className={`nav-item ${view === id ? 'active' : ''}`} onClick={() => {
          setView(id);
          if (id === 'reports') refreshHistory();
        }}><Icon size={18} />{label}{id === 'evaluate' && <span className="nav-dot" />}</button>)}
      </nav>
      <div className="sidebar-bottom"><div className="privacy"><ShieldCheck size={20} /><strong>Your code stays here.</strong><p>Local models. Local execution.<br />No cloud API required.</p></div>
        <button className="help-link" onClick={() => setSetupOpen(true)}><CircleHelp size={17} /> Setup & documentation <ArrowUpRight size={15} /></button>
        <div className="profile"><span className="avatar">IN</span><div><strong>Instructor</strong><small>Local workspace</small></div><span className="online-dot" /></div>
      </div>
    </aside>

    <div className="main-shell">
      <header className="topbar"><div><span className="breadcrumb">Workspace</span><ChevronRight size={14} /><strong>{view === 'rules' ? 'Grading rules' : view === 'reports' ? 'Past evaluations' : 'New evaluation'}</strong></div>
        <button className={`connection ${health?.ready ? 'ready' : ''}`} onClick={checkHealth} title="Refresh backend readiness"><span className="status-dot" />{checking ? 'Checking services' : health?.ready ? 'Local engine ready' : health?.disconnected ? 'Backend offline' : 'Setup needed'}<RefreshCw size={13} className={checking ? 'spin' : ''} /></button>
      </header>
      <main>
        <section className="page-heading"><div><div className="eyebrow">{view === 'rules' ? 'DEFINE THE STANDARD' : view === 'reports' ? 'EVERY VERDICT, WITH EVIDENCE' : 'YOUR LOCAL CODE REVIEW WORKSPACE'}</div><h1>{view === 'rules' ? 'Make the rules clear.' : view === 'reports' ? 'Past evaluations' : 'Evaluate a submission'}</h1><p>{view === 'rules' ? 'Set the criteria. Your specialist agents follow the same rubric.' : view === 'reports' ? 'Revisit feedback and download the original evaluation reports.' : 'From source code to meaningful feedback, one specialist at a time.'}</p></div>
          <span className="version-pill"><span />C11 · Ollama</span>
        </section>

        {error && <div className="error-banner" role="alert"><AlertCircle size={19} /><span>{error}</span><button aria-label="Dismiss error" onClick={() => setError('')}><X size={17} /></button></div>}
        {health && !health.ready && <div className="setup-banner"><span className="setup-icon"><Terminal size={17} /></span><div><strong>{health.disconnected ? 'Connect the Python backend' : 'Your workspace is ready. Finish the engine setup.'}</strong><span>{health.disconnected ? 'Start the API server to load rules and evaluate submissions.' : 'Real grading needs Ubuntu, the Docker sandbox, and your local Ollama model.'}</span></div><button onClick={() => setSetupOpen(true)}>Setup guide <ArrowUpRight size={15} /></button></div>}

        {view === 'evaluate' && <>
          <div className="evaluation-layout">
            <section className="card source-card">
              <div className="card-heading"><div><span className="step">01</span><h2>Submission</h2></div><button className="text-button" disabled={busy} onClick={() => {
                  setSource(SAMPLE);
                  setFilename('add.c');
                  setReport(null);
                }}>Load sample <ArrowUpRight size={14} /></button></div>
              <div className={`dropzone ${dragging ? 'dragging' : ''}`} onDragOver={e => {
                e.preventDefault();
                if (!busy) setDragging(true);
              }} onDragLeave={() => setDragging(false)} onDrop={e => {
                e.preventDefault();
                setDragging(false);
                if (!busy) loadSource(e.dataTransfer.files[0]);
              }}>
                <div className="upload-symbol"><Upload size={22} /></div><div><strong>Drop your C file here</strong><p>or <button disabled={busy} onClick={() => uploadRef.current.click()}>browse files</button> from your computer</p><small>Single .c file · up to 12 KB</small></div>
                <input ref={uploadRef} aria-label="Upload C source" type="file" accept=".c" hidden onChange={e => {
                  loadSource(e.target.files[0]);
                  e.target.value = '';
                }} />
              </div>
              <div className="editor"><div className="editor-bar"><FileCode2 size={16} /><input aria-label="Source filename" value={filename} disabled={busy} onChange={e => setFilename(e.target.value)} /><span>C source</span></div>
                <div className="code-area"><div className="line-numbers" aria-hidden="true">{Array.from({
                      length: lines
                    }, (_, i) => <div key={i}>{i + 1}</div>)}</div><textarea aria-label="C source code" spellCheck="false" value={source} onChange={e => setSource(e.target.value)} disabled={busy} /></div>
                <div className="editor-footer"><span><span className="green-dot" /> {filename}</span><span>{lines} lines <i /> UTF-8</span></div>
              </div>
              <div className="run-area"><div className="run-info"><ShieldCheck size={17} /><span>Compiled and executed in an isolated sandbox</span></div><button className="primary-button" disabled={busy || !source.trim() || !rulesText} onClick={evaluate}>{busy ? <LoaderCircle size={18} className="spin" /> : <Play size={17} fill="currentColor" />}{busy ? job?.status === 'queued' ? 'Waiting for evaluator…' : 'Evaluating submission…' : 'Evaluate submission'}{!busy && <ArrowRight size={18} />}</button><p>Compilation, test cases, and {metrics.length || 9} specialist reviews in one run.</p></div>
            </section>
            <aside className="card rubric-card"><div className="card-heading"><div><span className="step">02</span><h2>Evaluation rubric</h2></div><span className="small-badge">{metrics.length} metrics</span></div>
              <div className="rubric-description">A balanced view of correctness,<br />quality, and reliability.</div>
              <div className="metric-list">{metrics.map((m, i) => {
                  const Icon = metricIcons[m.name] || ClipboardCheck;
                  return <div className="metric-row" key={`${m.name}-${i}`}><span className={`metric-icon tone-${i % 3}`}><Icon size={17} /></span><span>{metricNames[m.name] || m.name}</span><strong>{Math.round(m.weight * 100)}<small>%</small></strong></div>;
                })}</div>
              <div className="weight-total"><span>Total weight</span><strong>{Math.round(metrics.reduce((s, m) => s + Number(m.weight || 0), 0) * 100)}% <CheckCircle2 size={15} /></strong></div>
              <button className="secondary-button full" onClick={() => setView('rules')}><SlidersHorizontal size={15} /> Configure grading rules</button>
              <div className="limits"><div><Clock3 size={15} /><span>Time limit<strong>{rules?.time_limit_s ?? '—'}s</strong></span></div><div><HardDrive size={15} /><span>Memory limit<strong>{rules?.memory_limit_mb ?? '—'} MB</strong></span></div></div>
            </aside>
          </div>
          {busy && <div className="progress-panel" role="status"><LoaderCircle className="spin" size={23} /><div><strong>{job?.status === 'queued' ? 'Your submission is queued' : 'The specialists are reviewing your code'}</strong><p>Compiling, running tests, and requesting local model reviews. This can take several minutes. You can keep this tab open.</p></div></div>}
          {report ? <section className="card results" ref={resultsRef}><div className="result-heading"><div><div className="eyebrow">EVALUATION COMPLETE</div><h2>{report.submission || 'Submission report'}</h2><p>{report.status} {report.cache_hit ? '· Replayed from verified cache' : '· New evaluation'}</p></div><div className="score">{report.grade === null ? '—' : Number(report.grade).toFixed(1)}<span>/ 100</span></div></div>
            <div className="result-toolbar"><div className="tabs">{['feedback', 'json'].map(tab => <button key={tab} className={resultTab === tab ? 'selected' : ''} onClick={() => setResultTab(tab)}>{tab === 'feedback' ? 'Metric breakdown' : 'Backend JSON'}</button>)}</div><div className="downloads"><button title="Download JSON report" onClick={() => download(JSON.stringify(report, null, 2), 'report.json', 'application/json')}><ArrowDownToLine size={15} /> JSON</button><button title="Download text report" onClick={() => download(textReport, 'report.txt', 'text/plain')}><ArrowDownToLine size={15} /> TXT</button></div></div>
            {resultTab === 'json' ? <pre className="json-result">{JSON.stringify(report, null, 2)}</pre> : <div className="results-list">{report.metrics.map((m, i) => <details key={i}><summary><span className={`result-dot ${m.status !== 'ok' || m.score < .7 ? 'warning' : ''}`} /><strong>{metricNames[m.name] || m.name}</strong><span className="metric-status">{m.status}</span><b>{Number(m.contribution).toFixed(1)} <small>/ {(m.weight * 100).toFixed(0)}</small></b></summary><p>{m.feedback}</p>{(m.evidence?.failing || []).map((f, n) => <pre key={n}>Input: {JSON.stringify(f.input)}{'\n'}Expected: {JSON.stringify(f.expected)}{'\n'}Actual: {JSON.stringify(f.got)}{'\n'}{f.stderr}</pre>)}{m.evidence?.review?.findings?.map((f, n) => <p key={n}>Line {f.line}: {f.explanation}</p>)}</details>)}</div>}
          </section> : !busy && <div className="how-it-works"><span>BUILT FOR EVIDENCE, NOT GUESSWORK</span><div><span><Terminal size={16} /> Compile & test</span><ChevronRight size={14} /><span><Cpu size={16} /> Specialist review</span><ChevronRight size={14} /><span><FileJson2 size={16} /> Explainable report</span></div></div>}
        </>}

        {view === 'rules' && <section className="card rules-page"><div className="card-heading"><div><FileJson2 size={20} /><h2>Instructor rules</h2></div><div className="button-group"><button className="secondary-button" disabled={busy} onClick={() => rulesUploadRef.current.click()}><Upload size={15} /> Import JSON</button><button className="secondary-button" onClick={() => download(rulesText, 'rules.json', 'application/json')}><ArrowDownToLine size={15} /> Export</button></div></div><input hidden ref={rulesUploadRef} type="file" accept=".json" onChange={e => {
            loadRules(e.target.files[0]);
            e.target.value = '';
          }} />
          <p className="rules-description">Edit weights, test cases, resource limits, and specialist instructions. Changes apply to your next evaluation.</p><textarea className="rules-editor" aria-label="Grading rules JSON" spellCheck="false" value={rulesText} onChange={e => setRulesText(e.target.value)} disabled={busy} /><div className="rules-footer"><span className={rulesError ? 'invalid' : 'valid'}>{rulesError ? <AlertCircle size={16} /> : <CheckCircle2 size={16} />} {rulesError ? rulesError : 'JSON is valid · Weights total 100% · Backend validates all fields on evaluation'}</span><button className="primary-button" onClick={() => setView('evaluate')} disabled={!!rulesError}>Use these rules <ArrowRight size={16} /></button></div>
        </section>}

        {view === 'reports' && <section className="card history-page"><div className="card-heading"><div><FolderClock size={20} /><h2>Saved reports</h2></div><button className="text-button" onClick={refreshHistory}><RefreshCw size={15} /> Refresh</button></div>{!history.length ? <div className="empty-state"><span><FolderClock size={30} /></span><h2>A fresh start.</h2><p>Your completed evaluations will appear here.<br />Every report keeps its feedback and original JSON.</p><button className="primary-button" onClick={() => setView('evaluate')}><Plus size={17} /> Start an evaluation</button></div> : <div className="history-list">{history.map((item, i) => <button key={i} onClick={() => openReport(item)}><FileCode2 size={21} /><span><strong>{item.submission}</strong><small>{item.status} · {item.id.slice(0, 12)}</small></span><b>{item.grade === null ? 'Incomplete' : `${item.grade} / 100`}</b><ArrowUpRight size={17} /></button>)}</div>}</section>}
        <footer className="page-footer"><span>AutoGrader <span>·</span> Thoughtful feedback. Local intelligence.</span><span><ShieldCheck size={13} /> Instructor workspace</span></footer>
      </main>
    </div>
    {setupOpen && <div className="modal-overlay" onClick={() => setSetupOpen(false)}><section role="dialog" aria-modal="true" aria-label="Local engine setup" className="setup-modal" onClick={e => e.stopPropagation()}><button className="close-modal" aria-label="Close setup" onClick={() => setSetupOpen(false)}><X size={20} /></button><span className="modal-icon"><Terminal size={28} /></span><h2>Connect your local engine</h2><p>The interface runs in your browser. Evaluation runs on Ubuntu with Docker and Ollama.</p><div className="service-checks">{Object.entries(health?.checks || {}).map(([key, value]) => <div key={key}><span className={value.ready ? 'valid' : 'invalid'}>{value.ready ? <CheckCircle2 size={17} /> : <AlertCircle size={17} />}</span><strong>{key}</strong><span>{value.detail}</span></div>)}</div><pre>{'bash scripts/setup.sh\nollama pull qwen2.5-coder:7b\ndocker build -t autograder-sandbox:1 sandbox/\nbash scripts/start.sh'}</pre><p>Requires Python 3.10+, Node.js 22.12+, Docker, and Ollama. See <code>README.md</code> for installation and separate development servers.</p><button className="primary-button full" onClick={checkHealth}><RefreshCw size={16} className={checking ? 'spin' : ''} />{checking ? 'Checking…' : 'Check connection again'}</button></section></div>}
  </div>;
}
createRoot(document.getElementById('root')).render(<App />);
