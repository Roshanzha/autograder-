"""A small shared context keeps analyzers independent of the frontend."""
from dataclasses import dataclass
from typing import Any
from ..models import Result


@dataclass
class Context:
    source: str
    rules: Any
    sandbox: Any
    llm: Any
    prompt: str
    binary: str | None
    compilation: dict
    corpus: dict[str, str]
    edges: list


class Analyzer:
    execution_based = False

    def analyze(self, ctx: Context, params: dict) -> Result:
        raise NotImplementedError


def passed(run):
    return run["status"] == "exited" and run["returncode"] == 0


def evaluate_cases(ctx, cases, binary=None, sanitize=False):
    """Each failure retains the actual input and independently known expected output."""
    records = []
    for case in cases:
        run = ctx.sandbox.run(binary or ctx.binary, case.input, ctx.rules, sanitize=sanitize)
        actual = run["stdout"]
        equal = actual == case.expected if ctx.rules.comparison == "exact" else actual.split() == case.expected.split()
        ok = passed(run) and (sanitize or equal)
        records.append({"name": case.name, "input": case.input, "expected": case.expected,
                        "got": actual, "passed": ok, **run})
    count = sum(item["passed"] for item in records)
    return Result(score=count / len(records), feedback=f"{count}/{len(records)} cases passed.",
                  evidence={"tests_passed": count, "tests_total": len(records),
                            "failing": [r for r in records if not r["passed"]], "cases": records})
